"""Main client facade for local/remote and HTTP/parser Tamarin workflows."""

from __future__ import annotations

import json
import logging
import shlex
import subprocess
import tempfile
import uuid
from pathlib import Path
import re
from typing import Any, Callable

from tamarin_infra import goals as _goals
from tamarin_infra import navigation as _navigation
from tamarin_infra.navigation import Navigator
from tamarin_infra.net.browser import BrowserClient
from tamarin_infra.net.http import HttpClient
from tamarin_infra.parsing import parser as tamarin_parser
from tamarin_infra.proc import LocalTamarinProc, RemoteTamarinProc
from tamarin_infra.proof import extraction as _extraction
from tamarin_infra.proof import graph as _graph

LOGGER = logging.getLogger(__name__)

GoalSelector = Callable[
    [dict[str, list[str]], list[dict[str, Any]], dict[str, Any], str, int],
    str | dict[str, Any] | None,
]


class TamarinClient:
    """Main interface for controlling Tamarin interactions.

    The source-of-truth workflow always stays request-driven:
    - fetch page over HTTP
    - parse by parser helpers
    - decide next URL
    - navigate by URL

    Browser mode (`headless=False`) is visualization-only.
    """

    def __init__(self, mode: str = "local", headless: bool = True, **kwargs: Any) -> None:
        self.mode = mode
        self.headless = headless
        self.options = dict(kwargs)

        if self.mode not in {"local", "remote"}:
            raise ValueError("mode must be either 'local' or 'remote'.")

        self.proc = self._build_proc()
        self.parser = tamarin_parser.TamarinParser()
        self.http_client = HttpClient(
            base_url=self.options.get("base_url"),
            timeout=self._safe_float(self.options.get("http_timeout")),
        )
        self.browser_client: BrowserClient | None = None
        if not self.headless:
            self.browser_client = BrowserClient(
                headless=False,
                timeout=self._safe_float(self.options.get("browser_timeout")),
            )

        self._nav = Navigator(
            http=self.http_client,
            browser=self.browser_client,
            parser=self.parser,
        )
        initial_theory_name = self._safe_str(self.options.get("theory_name"))
        if initial_theory_name:
            self._nav.current_theory_name = initial_theory_name

        self.connected: bool = False
        self.started: bool = False

        self.current_theory_path: str | None = None
        self.current_goal: str | None = None
        self.current_goals_by_case: dict[str, list[str]] = {}

        self._action_history: list[str] = []
        self._latest_proof_steps: list[dict[str, Any]] = []

    @property
    def current_url(self) -> str | None:
        return self._nav.current_url

    @current_url.setter
    def current_url(self, value: str | None) -> None:
        self._nav.current_url = value

    @property
    def current_state(self) -> dict[str, Any] | None:
        return self._nav.current_state

    @current_state.setter
    def current_state(self, value: dict[str, Any] | None) -> None:
        self._nav.current_state = value

    @property
    def current_theory_name(self) -> str | None:
        return self._nav.current_theory_name

    @current_theory_name.setter
    def current_theory_name(self, value: str | None) -> None:
        self._nav.current_theory_name = value

    @property
    def current_lemma(self) -> str | None:
        return self._nav.current_lemma

    @current_lemma.setter
    def current_lemma(self, value: str | None) -> None:
        self._nav.current_lemma = value

    def _build_proc(self) -> LocalTamarinProc | RemoteTamarinProc:
        """Create process backend based on mode and options."""
        timeout = self._safe_float(self.options.get("timeout"), fallback=30.0)
        tamarin_binary = self._safe_str(self.options.get("tamarin_binary")) or "tamarin-prover"
        workdir = self._safe_str(self.options.get("workdir")) or "."
        ui_port = self._safe_int(self.options.get("port"), fallback=3001)

        if self.mode == "local":
            host = self._safe_str(self.options.get("host")) or "127.0.0.1"
            return LocalTamarinProc(
                host=host,
                port=ui_port,
                workdir=workdir,
                timeout=timeout,
                tamarin_binary=tamarin_binary,
                env=self.options.get("env"),
                log_file=self._safe_str(self.options.get("log_file")),
            )

        host = self._safe_str(self.options.get("host"))
        user = self._safe_str(self.options.get("user"))
        if not host or not user:
            raise ValueError("Remote mode requires non-empty 'host' and 'user'.")

        remote_ui_port = self._safe_int(self.options.get("remote_ui_port"), fallback=ui_port)
        look_for_keys = bool(self.options.get("look_for_keys", True))
        allow_agent = bool(self.options.get("allow_agent", True))

        return RemoteTamarinProc(
            host=host,
            user=user,
            ssh_port=self._safe_int(self.options.get("ssh_port"), fallback=22),
            port=remote_ui_port,
            workdir=workdir,
            timeout=timeout,
            tamarin_binary=tamarin_binary,
            password=self._safe_str(self.options.get("password")),
            key_filename=self._safe_str(self.options.get("key_filename")),
            look_for_keys=look_for_keys,
            allow_agent=allow_agent,
            remote_ui_host=self._safe_str(self.options.get("remote_ui_host")) or "127.0.0.1",
            local_forward_host=self._safe_str(self.options.get("local_forward_host")) or "127.0.0.1",
            local_forward_port=self._safe_int(self.options.get("local_forward_port"), fallback=0),
            remote_log_file=self._safe_str(self.options.get("remote_log_file")) or "tamarin_interactive.log",
        )

    def connect(self) -> None:
        """Establish connectivity for the selected backend."""
        if self.mode == "remote":
            self._require_remote_proc().connect()
        self.connected = True

    def disconnect(self) -> None:
        """Release connectivity for the selected backend."""
        if self.mode == "remote":
            self._require_remote_proc().disconnect()
        self.connected = False

    def start(self, *args: Any, **kwargs: Any) -> None:
        """Start Tamarin runtime via process backend and prepare HTTP base URL."""
        if self.mode == "remote" and not self.connected:
            raise RuntimeError("Remote mode requires connect() before start().")
        if self.mode == "local" and not self.connected:
            # Local mode does not require a separate network handshake.
            self.connected = True

        self.proc.start(*args, **kwargs)
        self.started = True

        runtime_base_url = self._resolve_runtime_base_url()
        self.http_client.set_base_url(runtime_base_url)
        self.current_url = self._navigate("/", update_state=True)
        LOGGER.info("Tamarin runtime started. base_url=%s", runtime_base_url)

    def stop(self) -> None:
        """Stop Tamarin runtime via process backend and reset runtime state."""
        self.proc.stop()
        self.started = False
        if self.mode == "remote":
            self.connected = False

        self.current_lemma = None
        self.current_goal = None
        self.current_url = None
        self.current_state = None
        self.current_goals_by_case = {}
        self._action_history = []
        self._latest_proof_steps = []

        if self.browser_client is not None:
            self.browser_client.close()

    def upload_theory(self, filepath: str) -> None:
        """Register and select active theory context."""
        value = (filepath or "").strip()
        if not value:
            raise ValueError("filepath cannot be empty.")

        self.current_theory_path = value
        inferred_name = self._extract_theory_name_from_file(Path(value))
        if not inferred_name:
            inferred_name = Path(value).stem.strip() or None
        self.current_theory_name = inferred_name

        if not self.started:
            return

        html = self._refresh_current_html()
        base_url = self.current_url or self.http_client.base_url
        target_url = self._resolve_theory_url_by_origin_path(
            html=html,
            theory_path=value,
            base_url=base_url,
        )

        # Fallback to theory-name matching when origin-based matching is unavailable.
        if not target_url and self.current_theory_name:
            target_url = tamarin_parser.resolve_theory_url(
                html=html,
                theory_name=self.current_theory_name,
                base_url=base_url,
            )

        if target_url:
            self.current_url = self._navigate(target_url, update_state=True)

    def download_proof(self, filepath: str) -> None:
        """Download the exported proof/theory file from current page."""
        if not filepath or not filepath.strip():
            raise ValueError("filepath cannot be empty.")
        html = self._refresh_current_html()
        download_url = tamarin_parser.resolve_download_url(
            html=html,
            base_url=self.current_url or self.http_client.base_url,
        )
        if not download_url:
            raise RuntimeError("Download link was not found on the current page.")
        self.http_client.download(download_url, filepath)

    def select_lemma(self, name: str) -> None:
        """Select a lemma by URL resolution from current page HTML."""
        lemma_name = (name or "").strip()
        if not lemma_name:
            raise ValueError("Lemma name cannot be empty.")

        if tamarin_parser.extract_lemma_from_proof_url(self.current_url) == lemma_name:
            self.current_lemma = lemma_name
            self.current_goal = None
            return

        html = self._refresh_current_html()
        target_url = tamarin_parser.resolve_lemma_proof_url(
            html=html,
            lemma_name=lemma_name,
            base_url=self.current_url or self.http_client.base_url,
        )
        if not target_url:
            raise RuntimeError(f"Lemma '{lemma_name}' was not found in current page.")

        self.current_url = self._navigate(target_url, update_state=True)
        self.current_lemma = lemma_name
        self.current_goal = None
        self.current_goals_by_case = {}
        self._action_history = []

    def list_lemmas(self) -> list[str]:
        """List lemmas available in current theory page context."""
        html = self._refresh_current_html()
        return tamarin_parser.extract_lemma_names(html=html, url=self.current_url)

    def select_goal(self, goal_id: str) -> None:
        """Select one goal/candidate by id/rule/href and navigate to its URL."""
        target = (goal_id or "").strip()
        if not target:
            raise ValueError("goal_id cannot be empty.")

        html = self._refresh_current_html()
        candidates = self.parser.parse_goals(
            html=html,
            url=self.current_url or self.http_client.base_url,
            absolute_href=True,
        )
        matched = _goals.match_candidate(candidates=candidates, goal_id=target)
        if matched is None:
            raise RuntimeError(f"Goal '{target}' was not found in current page candidates.")

        href = self._safe_str(matched.get("href"))
        if not href:
            raise RuntimeError(
                f"Goal '{target}' has no executable URL. "
                "Current parser did not resolve a navigable target."
            )

        self.current_url = self._navigate(href, update_state=True)
        self.current_goal = target
        rule_text = self._safe_str(matched.get("rule"))
        if rule_text:
            self._action_history.append(rule_text)

    def list_goals(self) -> dict[str, list[str]]:
        """List executable goals grouped by case name."""
        html = self._refresh_current_html()

        def fetch_case(case_url: str) -> list[dict[str, Any]]:
            return self._fetch_case_candidates(case_url=case_url)

        candidates = self.parser.parse_goals(
            html=html,
            url=self.current_url or self.http_client.base_url,
            absolute_href=False,
        )
        grouped = _goals.group_goals_by_case(
            candidates=candidates,
            html=html,
            current_url=self.current_url or self.http_client.base_url,
            fetch_fn=fetch_case,
        )
        self.current_goals_by_case = grouped
        return grouped

    def list_goal_candidates(
        self,
        *,
        absolute_href: bool = True,
        refresh: bool = True,
    ) -> list[dict[str, Any]]:
        """List current executable candidates with id/rule/href metadata."""
        if refresh:
            html = self._refresh_current_html()
        else:
            html = self._require_document_html()
        return self.parser.parse_goals(
            html=html,
            url=self.current_url or self.http_client.base_url,
            absolute_href=absolute_href,
        )

    def get_state(self, *, refresh: bool = True) -> dict[str, Any]:
        """Return current parsed interactive state."""
        if refresh:
            return self._refresh_and_get_state()
        if isinstance(self.current_state, dict):
            return self.current_state
        return self._refresh_and_get_state()

    def get_proof_state(self, *, refresh: bool = True) -> dict[str, Any]:
        """Return normalized proof state object."""
        state = self.get_state(refresh=refresh)
        return self._normalize_proof_state(state.get("proof_state"))

    def is_current_proof_finished(self, *, refresh: bool = True) -> bool:
        """Check whether current proof page is in a terminal finished state."""
        return self.get_proof_state(refresh=refresh).get("state") == "finished"

    def ensure_remote_ui_port_available(self, port: int | None = None) -> dict[str, Any]:
        """Ensure remote UI port is free before starting interactive runtime."""
        if self.mode != "remote":
            target = self._safe_int(port, fallback=self._safe_int(self.options.get("port"), fallback=3001))
            return {
                "port": target,
                "occupied_before": False,
                "killed_pids": [],
                "remaining_pids": [],
            }
        remote_proc = self._require_remote_proc()
        target_port = self._safe_int(port, fallback=remote_proc.remote_ui_port)
        return remote_proc.ensure_port_available(target_port)

    def ensure_theory_selected_by_origin(self, theory_path: str) -> tuple[bool, str | None]:
        """Ensure theory page is selected by origin path from index table."""
        if self._is_theory_page_url(self.current_url):
            return True, None

        html = self._refresh_current_html()
        base_url = self.current_url or self.http_client.base_url
        target_url = self._resolve_theory_url_by_origin_path(
            html=html,
            theory_path=theory_path,
            base_url=base_url,
        )
        if not target_url:
            return False, None
        self.current_url = self._navigate(target_url, update_state=True)
        return True, target_url

    def proof_path(
        self,
        *,
        lemma: str | None = None,
        upto_step: int | None = None,
        steps: list[dict[str, Any]] | None = None,
    ) -> list[str]:
        """Return concatenated selected goals up to the requested step."""
        source_steps = steps if isinstance(steps, list) else self._latest_proof_steps
        target_lemma = (lemma or self.current_lemma or "").strip()
        filter_by_lemma = bool(target_lemma)
        limit = upto_step if isinstance(upto_step, int) and upto_step > 0 else None

        result: list[str] = []
        matched_step_count = 0

        for item in source_steps:
            if not isinstance(item, dict):
                continue

            item_lemma = str(item.get("lemma") or "").strip()
            if filter_by_lemma and item_lemma != target_lemma:
                continue

            selected_goal = str(item.get("selected_goal") or "").strip()
            if not selected_goal:
                continue

            matched_step_count += 1
            if limit is not None and matched_step_count > limit:
                break
            result.append(selected_goal)

        return result

    def generate_action_blocks(
        self,
        *,
        lemma_name: str,
        proof_graph: dict[str, Any] | str | Path,
        model_file: str | Path | None = None,
    ) -> list[dict[str, object]]:
        """Extract protocol causal chain from proof graph and build action blocks."""
        selected_model_file = model_file or self.current_theory_path
        if not selected_model_file:
            raise ValueError(
                "model_file is required when current_theory_path is empty. "
                "Pass model_file explicitly or call upload_theory(...) first."
            )

        case_order = _graph.parse_lemma_case_order(lemma_name, proof_graph)

        from tamarin_infra.utils.action_blocks import (
            generate_action_blocks as _generate_action_blocks,
        )

        return _generate_action_blocks(
            case_order=case_order,
            model_file=selected_model_file,
        )

    def extract_action_blocks(
        self,
        model_file: str | Path | None = None,
        lemma_name: str = "executable",
        *,
        output_dir: str | Path | None = None,
        yaml_file_name: str = "action_blocks.yaml",
        extra_args: list[str] | None = None,
        timeout: float | None = None,
    ) -> list[dict[str, object]]:
        """Verify a model, derive action blocks for a lemma, optionally write YAML."""
        selected_model_file = model_file or self.current_theory_path
        if not selected_model_file:
            raise ValueError(
                "model_file is required when current_theory_path is empty. "
                "Pass model_file explicitly or call upload_theory(...) first."
            )

        target_lemma = (lemma_name or "").strip()
        if not target_lemma:
            raise ValueError("lemma_name cannot be empty.")

        verify_extra_args = [f"--prove={target_lemma}", "--auto-sources"]
        verify_extra_args.extend(str(item) for item in (extra_args or []))

        proof_graph = self.verify_model(
            str(selected_model_file),
            as_json=True,
            prove=False,
            extra_args=verify_extra_args,
            timeout=timeout,
        )
        if not isinstance(proof_graph, dict):
            raise RuntimeError("verify_model did not return a JSON object for the proof graph.")

        blocks = self.generate_action_blocks(
            lemma_name=target_lemma,
            proof_graph=proof_graph,
            model_file=selected_model_file,
        )

        if output_dir is not None:
            from tamarin_infra.utils.action_blocks import (
                write_action_blocks_yaml as _write_action_blocks_yaml,
            )

            _write_action_blocks_yaml(
                blocks,
                output_dir=output_dir,
                file_name=yaml_file_name,
            )

        return blocks

    def prove_lemmas(
        self,
        *,
        max_steps: int = 100,
        target_lemma: str | None = None,
        goal_selector: GoalSelector | None = None,
    ) -> dict[str, Any]:
        """Prove target lemmas with externally supplied goal-selection strategy."""
        if goal_selector is None:
            raise ValueError(
                "prove_lemmas requires a goal_selector callback. "
                "Candidate selection must be controlled by the caller."
            )

        lemmas = self.list_lemmas()
        target_lemmas = _extraction.choose_target_lemmas(lemmas=lemmas, target_lemma=target_lemma)

        steps: list[dict[str, Any]] = []
        lemma_process: dict[str, list[dict[str, Any]]] = {name: [] for name in target_lemmas}
        lemma_proof_states: dict[str, dict[str, Any]] = {}
        visited_lemmas: list[str] = []
        global_step_index = 0

        for lemma_name in target_lemmas:
            self.select_lemma(lemma_name)
            if lemma_name not in visited_lemmas:
                visited_lemmas.append(lemma_name)

            for _step in range(1, max_steps + 1):
                state = self.get_state(refresh=True)
                current_proof_state = self._normalize_proof_state(state.get("proof_state"))
                if current_proof_state["state"] == "finished":
                    lemma_proof_states[lemma_name] = current_proof_state
                    break

                current_list_goals = self.list_goals()
                current_candidates = self.list_goal_candidates(absolute_href=True, refresh=False)
                current_state = self.current_state if isinstance(self.current_state, dict) else state
                current_url_before_action = self.current_url
                current_constraint_system = self._normalize_constraint_system(
                    current_state.get("constraint_system") if isinstance(current_state, dict) else {}
                )

                step_index_for_lemma = len(lemma_process[lemma_name]) + 1
                selected = goal_selector(
                    current_list_goals,
                    current_candidates,
                    current_state,
                    lemma_name,
                    step_index_for_lemma,
                )
                candidate = _goals.resolve_selected_candidate(
                    selected=selected,
                    candidates=current_candidates,
                )
                if candidate is None:
                    lemma_proof_states[lemma_name] = current_proof_state
                    break

                goal_id = str(candidate.get("id") or candidate.get("rule") or "").strip()
                if not goal_id:
                    lemma_proof_states[lemma_name] = current_proof_state
                    break

                rule_text = str(candidate.get("rule") or goal_id).strip()
                selected_goal = _extraction.format_selected_goal(
                    selected_candidate=rule_text,
                    grouped_goals=current_list_goals,
                )

                global_step_index += 1
                step_entry = {
                    "step": global_step_index,
                    "lemma": lemma_name,
                    "selected_goal_id": goal_id,
                    "selected_goal": selected_goal,
                    "selected_href": str(candidate.get("href") or ""),
                    "url": current_url_before_action,
                    "list_goals": current_list_goals,
                    "proof_state": current_proof_state,
                    "constraint_system": current_constraint_system,
                }
                steps.append(step_entry)

                lemma_entry = dict(step_entry)
                lemma_entry["step"] = step_index_for_lemma
                lemma_process[lemma_name].append(lemma_entry)

                self.select_goal(goal_id)

                post_state = self.current_state if isinstance(self.current_state, dict) else {}
                post_proof_state = self._normalize_proof_state(post_state.get("proof_state"))
                if post_proof_state["state"] == "finished":
                    lemma_proof_states[lemma_name] = post_proof_state
                    break

                post_lemma = _extraction.extract_lemma_for_state(post_state, self.current_url)
                if post_lemma and post_lemma != lemma_name:
                    lemma_proof_states[lemma_name] = {"state": "finished", "result": "verified"}
                    break
            else:
                lemma_proof_states[lemma_name] = {"state": "unfinished", "result": "max_steps_reached"}

        final_state = self._refresh_and_get_state()
        success = all(
            str(lemma_proof_states.get(name, {}).get("state") or "").strip() == "finished"
            and str(lemma_proof_states.get(name, {}).get("result") or "").strip() == "verified"
            for name in target_lemmas
        )
        self._latest_proof_steps = steps

        return {
            "lemmas": lemmas,
            "target_lemmas": target_lemmas,
            "steps": steps,
            "lemma_process": lemma_process,
            "lemma_proof_states": lemma_proof_states,
            "visited_lemmas": visited_lemmas,
            "final_state": final_state,
            "success": success,
        }

    def write_lemma_reports(
        self,
        *,
        output_dir: str | Path,
        theory_name: str,
        lemma_process: dict[str, list[dict[str, Any]]],
        lemma_proof_states: dict[str, dict[str, Any]],
        visited_lemmas: list[str] | None = None,
    ) -> list[str]:
        """Write per-lemma JSON report files and return absolute file paths."""
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        selected_lemmas = [
            item for item in (visited_lemmas or list(lemma_process.keys())) if isinstance(item, str) and item.strip()
        ]
        theory_safe = self._safe_filename_part(theory_name)
        saved_files: list[str] = []

        for lemma_name in selected_lemmas:
            raw_steps = lemma_process.get(lemma_name, [])
            normalized_steps: list[dict[str, Any]] = []
            for step_index, step in enumerate(raw_steps, start=1):
                if not isinstance(step, dict):
                    continue
                normalized_step = dict(step)
                normalized_step["step"] = step_index
                normalized_step["constraint_system"] = self._normalize_constraint_system(
                    normalized_step.get("constraint_system")
                )
                normalized_steps.append(normalized_step)

            proof_state_raw = lemma_proof_states.get(lemma_name, {})
            proof_state = self._normalize_proof_state(proof_state_raw)
            payload = {
                "theory": theory_name,
                "lemma": lemma_name,
                "step_count": len(normalized_steps),
                "step": normalized_steps,
                "proof_state": proof_state,
            }

            file_name = f"{theory_safe}_{self._safe_filename_part(lemma_name)}.json"
            file_path = output_path / file_name
            file_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
            saved_files.append(str(file_path.resolve()))
        return saved_files

    def verify_model(
        self,
        model_file: str,
        *,
        as_json: bool = False,
        prove: bool = True,
        extra_args: list[str] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any] | str:
        """Run tamarin-prover on a model file and return the verification output.

        When `as_json` is True, the result is parsed JSON (dict). Otherwise the
        raw stdout text is returned. For remote mode the model file is uploaded
        to the remote working directory and any JSON output is downloaded back.
        """
        source = (model_file or "").strip()
        if not source:
            raise ValueError("model_file cannot be empty.")
        normalized_extra = [str(item) for item in (extra_args or [])]

        if self.mode == "local":
            return self._verify_local(
                model_file=source,
                as_json=as_json,
                prove=prove,
                extra_args=normalized_extra,
                timeout=timeout,
            )
        return self._verify_remote(
            model_file=source,
            as_json=as_json,
            prove=prove,
            extra_args=normalized_extra,
            timeout=timeout,
        )

    def _verify_local(
        self,
        *,
        model_file: str,
        as_json: bool,
        prove: bool,
        extra_args: list[str],
        timeout: float | None,
    ) -> dict[str, Any] | str:
        model_path = Path(model_file)
        if not model_path.is_file():
            raise FileNotFoundError(f"Model file not found: {model_file}")

        binary = self.proc.tamarin_binary
        cmd: list[str] = [binary]
        if prove:
            cmd.append("--prove")
        cmd.extend(extra_args)

        json_path: Path | None = None
        if as_json:
            json_path = Path(tempfile.gettempdir()) / f"tamarin-{uuid.uuid4().hex}.json"
            cmd.append(f"--output-json={json_path}")
        cmd.append(str(model_path))

        try:
            completed = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            if completed.returncode != 0:
                raise RuntimeError(
                    f"tamarin-prover failed (exit={completed.returncode}): "
                    f"{completed.stderr.strip() or completed.stdout.strip()}"
                )
            if as_json:
                if json_path is None or not json_path.is_file():
                    raise RuntimeError(
                        "tamarin-prover did not produce a JSON output file."
                    )
                return json.loads(json_path.read_text(encoding="utf-8"))
            return completed.stdout
        finally:
            if json_path is not None:
                try:
                    json_path.unlink()
                except (FileNotFoundError, OSError):
                    pass

    def _verify_remote(
        self,
        *,
        model_file: str,
        as_json: bool,
        prove: bool,
        extra_args: list[str],
        timeout: float | None,
    ) -> dict[str, Any] | str:
        model_path = Path(model_file)
        if not model_path.is_file():
            raise FileNotFoundError(f"Local model file not found: {model_file}")

        proc = self._require_remote_proc()
        proc.connect()
        proc.ensure_workdir()

        unique_tag = uuid.uuid4().hex
        remote_model_name = f"{unique_tag}-{model_path.name}"
        remote_model_path = proc.upload(str(model_path), remote_name=remote_model_name)

        cmd_parts: list[str] = [proc.tamarin_binary]
        if prove:
            cmd_parts.append("--prove")
        cmd_parts.extend(extra_args)

        remote_json_path: str | None = None
        if as_json:
            remote_json_path = f"{proc.workdir.rstrip('/')}/output-{unique_tag}.json"
            cmd_parts.append(f"--output-json={remote_json_path}")
        cmd_parts.append(remote_model_path)

        remote_command = " ".join(shlex.quote(part) for part in cmd_parts)
        effective_timeout = timeout if timeout is not None else proc.timeout

        try:
            result = proc.execute(remote_command, timeout=effective_timeout)
            exit_status = int(result.get("exit_status", -1))
            stdout = str(result.get("stdout", ""))
            stderr = str(result.get("stderr", ""))
            if exit_status != 0:
                raise RuntimeError(
                    f"tamarin-prover failed (exit={exit_status}): "
                    f"{stderr.strip() or stdout.strip()}"
                )

            if as_json:
                if not remote_json_path:
                    raise RuntimeError("Remote JSON output path was not set.")
                local_json_path = (
                    Path(tempfile.gettempdir()) / f"tamarin-{unique_tag}.json"
                )
                try:
                    proc.download(remote_json_path, str(local_json_path))
                    return json.loads(local_json_path.read_text(encoding="utf-8"))
                finally:
                    try:
                        local_json_path.unlink()
                    except (FileNotFoundError, OSError):
                        pass
            return stdout
        finally:
            proc.remove_remote_file(remote_model_path)
            if remote_json_path:
                proc.remove_remote_file(remote_json_path)

    def close(self) -> None:
        """Close all resources safely."""
        try:
            self.stop()
        except Exception:
            pass
        try:
            self.disconnect()
        except Exception:
            pass
        self.http_client.close()

    def __enter__(self) -> TamarinClient:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _resolve_runtime_base_url(self) -> str:
        return _navigation.resolve_runtime_base_url(self.proc, self.mode)

    def _refresh_current_html(self) -> str:
        self._ensure_started()
        return self._nav.refresh_html(action_history=tuple(self._action_history))

    def _navigate(self, url_or_path: str, *, update_state: bool) -> str:
        self._ensure_started()
        return self._nav.navigate(
            url_or_path,
            update_state=update_state,
            action_history=tuple(self._action_history),
        )

    def _require_document_html(self) -> str:
        return self._nav.require_html()

    def _refresh_and_get_state(self) -> dict[str, Any]:
        self._ensure_started()
        return self._nav.refresh_and_get_state(action_history=tuple(self._action_history))

    def _fetch_case_candidates(self, *, case_url: str) -> list[dict[str, Any]]:
        try:
            response = self.http_client.session.get(
                case_url,
                timeout=self.http_client.timeout,
            )
            response.raise_for_status()
        except Exception as exc:
            LOGGER.warning("Failed to fetch case URL %s: %s", case_url, exc)
            return []

        case_html = response.text or ""
        normalizer = getattr(self.http_client, "_normalize_response_body", None)
        if callable(normalizer):
            try:
                case_html = str(normalizer(body=case_html, response=response))
            except Exception:
                pass

        return self.parser.parse_goals(
            html=case_html,
            url=case_url,
            absolute_href=False,
        )

    @staticmethod
    def _normalize_constraint_system(value: Any) -> dict[str, Any]:
        if isinstance(value, dict):
            return value
        if value is None:
            return {}
        return {"raw": str(value)}

    @staticmethod
    def _normalize_proof_state(value: Any) -> dict[str, Any]:
        if isinstance(value, dict):
            return {
                "state": str(value.get("state") or "").strip() or "unknown",
                "result": str(value.get("result") or "").strip(),
            }
        return {"state": "unknown", "result": ""}

    @staticmethod
    def _is_theory_page_url(url: str | None) -> bool:
        return _navigation.is_theory_page_url(url)

    def _extract_theory_name_from_file(self, path: Path) -> str | None:
        return _navigation.extract_theory_name_from_file(path)

    def _resolve_theory_url_by_origin_path(
        self,
        *,
        html: str,
        theory_path: str,
        base_url: str | None,
    ) -> str | None:
        return _navigation.resolve_theory_url_by_origin_path(
            html=html,
            theory_path=theory_path,
            base_url=base_url,
        )

    def _ensure_started(self) -> None:
        if not self.started:
            raise RuntimeError("Tamarin runtime is not started. Call start() first.")

    def _require_remote_proc(self) -> RemoteTamarinProc:
        if not isinstance(self.proc, RemoteTamarinProc):
            raise RuntimeError("Remote process backend is not configured.")
        return self.proc

    @staticmethod
    def _safe_str(value: object) -> str | None:
        if isinstance(value, str):
            stripped = value.strip()
            if stripped:
                return stripped
        return None

    @staticmethod
    def _safe_filename_part(value: str) -> str:
        cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", (value or "").strip())
        cleaned = cleaned.strip("._")
        return cleaned or "theory"

    @staticmethod
    def _safe_int(value: object, *, fallback: int) -> int:
        try:
            return int(value) if value is not None else fallback
        except (TypeError, ValueError):
            return fallback

    @staticmethod
    def _safe_float(value: object, *, fallback: float | None = None) -> float | None:
        if value is None:
            return fallback
        try:
            return float(value)
        except (TypeError, ValueError):
            return fallback
