"""Goal grouping by case and candidate matching."""

from __future__ import annotations

import logging
import re
from typing import Any, Callable
from urllib.parse import unquote, urljoin, urlparse

from tamarin_infra.parsing import parser as tamarin_parser

LOGGER = logging.getLogger(__name__)


def group_goals_by_case(
    *,
    candidates: list[dict[str, Any]],
    html: str,
    current_url: str | None,
    fetch_fn: Callable[[str], list[dict[str, Any]]],
) -> dict[str, list[str]]:
    """Organize executable goals into case-name groups."""
    direct_rules = _dedupe_preserve_order(
        [
            _normalize_goal_line(_safe_str(item.get("rule")) or "")
            for item in candidates
            if _safe_str(item.get("rule"))
        ]
    )
    direct_rules = [rule for rule in direct_rules if rule and rule.lower() != "sorry"]

    case_links = _extract_case_link_map(html=html, current_url=current_url)
    if case_links:
        grouped: dict[str, list[str]] = {}
        for case_name, case_url in case_links.items():
            case_candidates = fetch_fn(case_url)
            case_rules: list[str] = []
            for item in case_candidates:
                kind = (_safe_str(item.get("kind")) or "").lower()
                rule = _safe_str(item.get("rule")) or ""
                if not rule or kind == "case":
                    continue
                normalized = _normalize_goal_line(rule)
                if normalized and normalized.lower() != "sorry":
                    case_rules.append(normalized)

            case_rules = _dedupe_preserve_order(case_rules)
            if not case_rules:
                case_rules = direct_rules
            grouped[case_name] = _normalize_case_goals(goals=case_rules)

        if grouped:
            return grouped

    if direct_rules:
        return {"default": _normalize_case_goals(goals=direct_rules)}
    return {"default": []}


def match_candidate(
    *,
    candidates: list[dict[str, Any]],
    goal_id: str,
) -> dict[str, Any] | None:
    """Find candidate by id/rule/href (case-insensitive)."""
    normalized = goal_id.strip().lower()
    for item in candidates:
        cid = (_safe_str(item.get("id")) or "").lower()
        rule = (_safe_str(item.get("rule")) or "").lower()
        href = (_safe_str(item.get("href")) or "").lower()
        if normalized in {cid, rule, href}:
            return item
    return None


def resolve_selected_candidate(
    *,
    selected: str | dict[str, Any] | None,
    candidates: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Convert goal_selector return value to matched candidate dict."""
    if selected is None:
        return None

    if isinstance(selected, str):
        value = selected.strip()
        if not value:
            return None
        return match_candidate(candidates=candidates, goal_id=value)

    if isinstance(selected, dict):
        for key in ("id", "rule", "href"):
            raw = selected.get(key)
            if not isinstance(raw, str):
                continue
            value = raw.strip()
            if not value:
                continue
            matched = match_candidate(candidates=candidates, goal_id=value)
            if matched is not None:
                return matched
        return None

    raise TypeError("goal_selector must return None, str, or dict with id/rule/href.")


def _extract_case_link_map(*, html: str, current_url: str | None) -> dict[str, str]:
    base_url = (current_url or "").strip()
    if not base_url:
        return {}

    current_path = urlparse(current_url).path if current_url else ""
    soup = tamarin_parser.build_soup(html)
    case_links: dict[str, str] = {}

    selectors = (
        "a.internal-link.proof-step.sorry-step[href], "
        "a.proof-step.sorry-step[href], "
        "a.sorry-step[href]"
    )
    for link in soup.select(selectors):
        link_text = (link.get_text(" ", strip=True) or "").strip().lower()
        if link_text != "sorry":
            continue

        href_raw = (str(link.get("href") or "")).strip()
        if not href_raw:
            continue
        resolved_href = urljoin(base_url, href_raw)
        case_name = _extract_case_name_from_sorry_href(
            current_path=current_path,
            href_url=resolved_href,
        )
        if not case_name:
            continue
        case_links.setdefault(case_name, resolved_href)
    return case_links


def _extract_case_name_from_sorry_href(*, current_path: str, href_url: str) -> str | None:
    base_path = (current_path or "").rstrip("/")
    href_path = urlparse(href_url).path.rstrip("/")
    token: str | None = None

    if base_path and href_path and href_path != base_path and href_path.startswith(base_path + "/"):
        suffix = href_path[len(base_path) + 1:]
        if suffix:
            token = unquote(suffix.split("/", 1)[0]).strip()

    if not token:
        base_suffix = _extract_proof_suffix(base_path)
        href_suffix = _extract_proof_suffix(href_path)
        if base_suffix and href_suffix and href_suffix.startswith(base_suffix + "/"):
            tail = href_suffix[len(base_suffix) + 1:]
            if tail:
                token = unquote(tail.split("/", 1)[0]).strip()

        if not token and base_suffix and href_suffix and "/" in base_suffix:
            parent_suffix = base_suffix.rsplit("/", 1)[0]
            if parent_suffix and href_suffix.startswith(parent_suffix + "/"):
                tail = href_suffix[len(parent_suffix) + 1:]
                if tail:
                    token = unquote(tail.split("/", 1)[0]).strip()

    if not token:
        return None
    if token in {"_", "main", "overview", "proof", "method"}:
        return None
    return token


def _extract_proof_suffix(path: str) -> str:
    normalized = (path or "").strip()
    for marker in ("/main/proof/", "/overview/proof/"):
        if marker in normalized:
            return normalized.split(marker, 1)[1].strip("/")
    return normalized.strip("/")


def _normalize_case_goals(*, goals: list[str]) -> list[str]:
    normalized_goals: list[str] = []
    for goal in _dedupe_preserve_order(goals):
        normalized_goal = _normalize_goal_line(goal)
        if not normalized_goal:
            continue
        if ":" in normalized_goal:
            _prefix, _sep, tail = normalized_goal.partition(":")
            if tail.strip():
                normalized_goals.append(tail.strip())
                continue
        normalized_goals.append(normalized_goal)
    return normalized_goals


def _normalize_goal_line(line: str) -> str:
    trimmed = line.strip()
    trimmed = re.sub(r"^[0-9A-Za-z]+\.\s*", "", trimmed)
    trimmed = re.sub(r"^\-\s*", "", trimmed)
    return trimmed.strip()


def _dedupe_preserve_order(values: list[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for item in values:
        normalized = item.strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        result.append(normalized)
    return result


def _safe_str(value: object) -> str | None:
    if isinstance(value, str):
        stripped = value.strip()
        if stripped:
            return stripped
    return None
