"""HTTP navigation, state caching, and theory URL resolution."""

from __future__ import annotations

import re
from pathlib import Path, PurePosixPath
from typing import Any
from urllib.parse import urljoin, urlparse

from tamarin_infra.net.browser import BrowserClient
from tamarin_infra.net.http import HttpClient
from tamarin_infra.parsing import parser as tamarin_parser


class Navigator:
    """Manage HTTP navigation, HTML caching, and parsed state for TamarinClient."""

    def __init__(
        self,
        *,
        http: HttpClient,
        browser: BrowserClient | None,
        parser: tamarin_parser.TamarinParser,
    ) -> None:
        self.http = http
        self.browser = browser
        self.parser = parser

        self.current_url: str | None = http.base_url
        self.current_state: dict[str, Any] | None = None
        self.current_theory_name: str | None = None
        self.current_lemma: str | None = None

    def navigate(
        self,
        url_or_path: str,
        *,
        update_state: bool,
        action_history: tuple[str, ...] = (),
    ) -> str:
        """GET url, update current_url, optionally sync browser and parse state."""
        if self.browser is not None:
            self.browser.wait_if_paused()
        response = self.http.get(url_or_path)
        resolved = self.http.last_url or response.url or self.http.resolve_url(url_or_path)
        self.current_url = resolved

        if self.browser is not None:
            if self.browser.current_url:
                self.browser.update(resolved)
            else:
                self.browser.open(resolved)

        if update_state:
            self._update_state_from_response(action_history=action_history)
        return resolved

    def refresh_html(
        self,
        *,
        action_history: tuple[str, ...] = (),
    ) -> str:
        """Re-fetch current URL HTML and update cached state."""
        if self.browser is not None:
            self.browser.wait_if_paused()
        target = self.current_url or "/"
        self.http.get(target)
        self.current_url = self.http.last_url or self.http.resolve_url(target)
        self._update_state_from_response(action_history=action_history)
        return self.require_html()

    def require_html(self) -> str:
        """Return cached HTML or raise."""
        html = self.http.last_document_html or self.http.last_body
        if not html:
            raise RuntimeError("No HTML content is available. Start and navigate first.")
        return html

    def refresh_and_get_state(
        self,
        *,
        action_history: tuple[str, ...] = (),
    ) -> dict[str, Any]:
        """Refresh HTML and return current state."""
        self.refresh_html(action_history=action_history)
        if isinstance(self.current_state, dict):
            return self.current_state
        return {}

    def _update_state_from_response(
        self,
        *,
        action_history: tuple[str, ...] = (),
    ) -> None:
        html = self.require_html()
        self.current_state = self.parser.parse_state(
            html=html,
            fallback_theory=self.current_theory_name,
            fallback_lemma=self.current_lemma,
            url=self.current_url,
            action_history=action_history,
        )
        if isinstance(self.current_state, dict):
            theory = _safe_str(self.current_state.get("theory"))
            lemma = _safe_str(self.current_state.get("lemma"))
            if theory:
                self.current_theory_name = theory
            if lemma:
                self.current_lemma = lemma


def resolve_runtime_base_url(proc: Any, mode: str) -> str:
    """Compute HTTP base URL from process backend."""
    if mode == "remote":
        if proc.forwarded_base_url:
            return proc.forwarded_base_url
        return f"http://{proc.host}:{proc.remote_ui_port}"
    return f"http://{proc.host}:{proc.port}"


def extract_theory_name_from_file(path: Path) -> str | None:
    """Parse 'theory NAME begin' from a .spthy file."""
    if not path.exists() or not path.is_file():
        return None
    try:
        content = path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None
    match = re.search(r"(?im)^\s*theory\s+([^\s]+)\s+begin\b", content)
    if not match:
        return None
    return match.group(1).strip()


def resolve_theory_url_by_origin_path(
    *,
    html: str,
    theory_path: str,
    base_url: str | None,
) -> str | None:
    """Resolve theory URL by matching table Origin column."""
    normalized_target = _normalize_posix_path(theory_path)
    if not normalized_target:
        return None
    target_basename = PurePosixPath(normalized_target).name

    soup = tamarin_parser.build_soup(html)
    best_href: str | None = None
    best_score = -1

    for row in soup.select("table tr"):
        link = row.select_one("td a[href]")
        if link is None:
            continue
        href = str(link.get("href") or "").strip()
        if not href:
            continue

        cells = row.select("td")
        if not cells:
            continue
        origin_text = cells[-1].get_text(" ", strip=True)
        normalized_origin = _normalize_posix_path(origin_text)
        if not normalized_origin:
            continue

        origin_basename = PurePosixPath(normalized_origin).name
        score = -1
        if normalized_origin == normalized_target:
            score = 5
        elif normalized_origin.endswith("/" + normalized_target):
            score = 4
        elif origin_basename == target_basename:
            score = 3
        elif target_basename and normalized_origin.endswith("/" + target_basename):
            score = 2

        if score > best_score:
            best_score = score
            best_href = href

    if best_href and base_url:
        return urljoin(base_url, best_href)
    return None


def is_theory_page_url(url: str | None) -> bool:
    """Check if URL is a theory page."""
    if not url:
        return False
    path = (urlparse(url).path or "").lower()
    return "/thy/trace/" in path and "/overview/" in path


def _normalize_posix_path(value: str) -> str:
    text = (value or "").strip()
    if not text:
        return ""
    normalized = text.replace("\\", "/")
    normalized = re.sub(r"/+", "/", normalized)
    normalized = re.sub(r"^\./+", "", normalized)
    normalized = normalized.strip().lower()
    if normalized.startswith("/"):
        normalized = normalized[1:]
    return normalized


def _safe_str(value: object) -> str | None:
    if isinstance(value, str):
        stripped = value.strip()
        if stripped:
            return stripped
    return None
