"""Lightweight browser display module.

This module is intentionally display-only:
- It opens and updates URLs provided by higher-level logic.
- It does not parse proof state.
- It does not decide next navigation targets.
"""

from __future__ import annotations

import logging
import threading
from typing import Any

LOGGER = logging.getLogger(__name__)


class BrowserClient:
    """Generic browser presenter for optional visualization."""

    def __init__(self, headless: bool = False, timeout: float | None = None) -> None:
        self.headless = headless
        self.timeout = timeout
        self.current_url: str | None = None

        self._playwright: Any | None = None
        self._browser: Any | None = None
        self._context: Any | None = None
        self._page: Any | None = None

        # Pause gate: set -> running, clear -> paused.
        self._run_event = threading.Event()
        self._run_event.set()
        self._state_lock = threading.Lock()

        # Global hotkey runtime fields.
        self._hotkey_backend: str | None = None
        self._hotkey_handles: list[Any] = []
        self._hotkey_listener: Any | None = None
        self._keyboard_module: Any | None = None
        self._hotkey_started: bool = False

    def start(self) -> None:
        """Start browser resources when display mode is enabled."""
        if self.headless:
            return
        if self._page is not None:
            return

        try:
            from playwright.sync_api import sync_playwright  # type: ignore
        except ImportError as exc:
            raise RuntimeError(
                "Playwright is required when headless=False. "
                "Install playwright and browser binaries first."
            ) from exc

        try:
            self._playwright = sync_playwright().start()
            # Visualization mode should show a real browser window.
            self._browser = self._playwright.chromium.launch(headless=False)
            self._context = self._browser.new_context()
            self._page = self._context.new_page()
            timeout_ms = self._timeout_ms()
            if timeout_ms is not None:
                self._page.set_default_timeout(timeout_ms)
            self._start_hotkeys()
        except Exception:
            self.close()
            raise

    def open(self, url: str) -> str:
        """Open a URL in browser, or just record it in headless mode."""
        target = (url or "").strip()
        if not target:
            raise ValueError("url cannot be empty.")

        self.wait_if_paused()
        self.current_url = target
        if self.headless:
            return target

        self.start()
        if self._page is None:
            raise RuntimeError("Browser page is not initialized.")

        goto_kwargs: dict[str, Any] = {"wait_until": "domcontentloaded"}
        timeout_ms = self._timeout_ms()
        if timeout_ms is not None:
            goto_kwargs["timeout"] = timeout_ms

        self._page.goto(target, **goto_kwargs)
        self.current_url = self._page.url or target
        return self.current_url

    def update(self, url: str) -> str:
        """Navigate the existing page to a new URL for display."""
        return self.open(url)

    def click(self, selector: str) -> None:
        """Click an element on the active page in visible-browser mode."""
        target = (selector or "").strip()
        if not target:
            raise ValueError("selector cannot be empty.")
        self.wait_if_paused()
        if self.headless:
            return
        if self._page is None:
            raise RuntimeError("Browser page is not initialized.")
        self._page.click(target)

    def wait_if_paused(self) -> None:
        """Block at a safe checkpoint while pause mode is active."""
        if self.headless:
            return
        self._run_event.wait()

    def pause(self) -> None:
        """Pause browser-driven automation checkpoints."""
        if self.headless:
            return
        with self._state_lock:
            if not self._run_event.is_set():
                return
            self._run_event.clear()
        self._hotkey_log("[HOTKEY] Paused by F4")

    def resume(self) -> None:
        """Resume browser-driven automation checkpoints."""
        if self.headless:
            return
        with self._state_lock:
            if self._run_event.is_set():
                return
            self._run_event.set()
        self._hotkey_log("[HOTKEY] Resumed by F5")

    @property
    def is_paused(self) -> bool:
        """Return whether pause mode is currently active."""
        return not self._run_event.is_set()

    def get_html(self) -> str:
        """Return current page HTML, or empty text when no page is active."""
        self.wait_if_paused()
        if self.headless or self._page is None:
            return ""
        return self._page.content()

    def get_text(self) -> str:
        """Return current page text, or empty text when no page is active."""
        self.wait_if_paused()
        if self.headless or self._page is None:
            return ""
        try:
            return self._page.inner_text("body").strip()
        except Exception:
            return self._page.evaluate("() => document.body ? document.body.innerText : ''").strip()

    def close(self) -> None:
        """Close browser resources safely."""
        if self._page is not None:
            try:
                self._page.close()
            except Exception:
                pass
            self._page = None

        if self._context is not None:
            try:
                self._context.close()
            except Exception:
                pass
            self._context = None

        if self._browser is not None:
            try:
                self._browser.close()
            except Exception:
                pass
            self._browser = None

        if self._playwright is not None:
            try:
                self._playwright.stop()
            except Exception:
                pass
            self._playwright = None

        self._stop_hotkeys()
        self._run_event.set()
        self.current_url = None

    def _timeout_ms(self) -> int | None:
        if self.timeout is None:
            return None
        if self.timeout <= 0:
            return 1
        return int(self.timeout * 1000)

    def _start_hotkeys(self) -> None:
        """Start global hotkey listener (F4 pause / F5 resume)."""
        if self.headless or self._hotkey_started:
            return

        if self._try_start_keyboard_backend():
            self._hotkey_started = True
            self._hotkey_log("[HOTKEY] Global hotkey listener started (F4 pause / F5 resume)")
            return

        if self._try_start_pynput_backend():
            self._hotkey_started = True
            self._hotkey_log("[HOTKEY] Global hotkey listener started (F4 pause / F5 resume)")
            return

        LOGGER.warning(
            "Global hotkeys are unavailable. Install `keyboard` or `pynput` for F4/F5 control."
        )

    def _stop_hotkeys(self) -> None:
        """Stop hotkey backends and release listeners."""
        if self._hotkey_backend == "keyboard" and self._keyboard_module is not None:
            for handle in self._hotkey_handles:
                try:
                    self._keyboard_module.remove_hotkey(handle)
                except Exception:
                    pass
            self._hotkey_handles.clear()
            self._keyboard_module = None

        if self._hotkey_backend == "pynput" and self._hotkey_listener is not None:
            try:
                self._hotkey_listener.stop()
            except Exception:
                pass
            self._hotkey_listener = None

        self._hotkey_backend = None
        self._hotkey_started = False

    def _try_start_keyboard_backend(self) -> bool:
        """Try global hotkeys via `keyboard` package."""
        try:
            import keyboard  # type: ignore
        except Exception:
            return False

        try:
            pause_handle = keyboard.add_hotkey("f4", self.pause, suppress=False, trigger_on_release=False)
            resume_handle = keyboard.add_hotkey("f5", self.resume, suppress=False, trigger_on_release=False)
        except Exception as exc:
            LOGGER.warning("`keyboard` backend failed for global hotkeys: %s", exc)
            return False

        self._keyboard_module = keyboard
        self._hotkey_handles = [pause_handle, resume_handle]
        self._hotkey_backend = "keyboard"
        return True

    def _try_start_pynput_backend(self) -> bool:
        """Try global hotkeys via `pynput` package."""
        try:
            from pynput import keyboard as pynput_keyboard  # type: ignore
        except Exception:
            return False

        def on_press(key: Any) -> None:
            try:
                if key == pynput_keyboard.Key.f4:
                    self.pause()
                elif key == pynput_keyboard.Key.f5:
                    self.resume()
            except Exception:
                return

        try:
            listener = pynput_keyboard.Listener(on_press=on_press)
            listener.daemon = True
            listener.start()
        except Exception as exc:
            LOGGER.warning("`pynput` backend failed for global hotkeys: %s", exc)
            return False

        self._hotkey_listener = listener
        self._hotkey_backend = "pynput"
        return True

    @staticmethod
    def _hotkey_log(message: str) -> None:
        LOGGER.info(message)
        print(message)
