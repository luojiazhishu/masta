"""Reusable HTTP/session/download helpers for Tamarin page access.

This module is intentionally transport-only:
- requests session lifecycle
- base URL resolution
- GET/POST requests
- response text/HTML retrieval
- file download

No parser, SSH, process, or browser interaction is implemented here.
"""

from __future__ import annotations

from html import escape
import json
import logging
from pathlib import Path
from typing import Any
from urllib.parse import urljoin, urlparse

import requests
from requests import Response, Session

LOGGER = logging.getLogger(__name__)

_DEFAULT_HEADERS = {
    "User-Agent": "tamarin_controller/0.1 (requests)",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
}


class HttpClient:
    """Lightweight HTTP client for Tamarin-style page and download access."""

    def __init__(
        self,
        base_url: str | None = None,
        timeout: float | None = None,
        session: Session | None = None,
    ) -> None:
        self.session: Session = session or requests.Session()
        self.session.headers.update(_DEFAULT_HEADERS)

        self.timeout: float | None = timeout
        self.base_url: str | None = None
        if base_url:
            self.set_base_url(base_url)

        self.last_url: str | None = None
        self.last_status_code: int | None = None
        self.last_body: str = ""
        self.last_document_html: str = ""

    def set_base_url(self, base_url: str) -> str:
        """Set and normalize base URL used for relative path resolution."""
        normalized = self._normalize_base_url(base_url)
        self.base_url = normalized
        return normalized

    def resolve_url(self, path: str) -> str:
        """Resolve absolute URL or join relative path with base URL."""
        target = (path or "").strip()
        if not target:
            if not self.base_url:
                raise ValueError("No path provided and base_url is not set.")
            return self.base_url

        parsed = urlparse(target)
        if parsed.scheme and parsed.netloc:
            return target

        if not self.base_url:
            raise ValueError(
                "Relative path requires base_url to be configured. "
                f"path={path!r}"
            )
        return urljoin(f"{self.base_url}/", target)

    def get(
        self,
        path: str,
        *,
        check_status: bool = True,
        follow_json_redirect: bool = True,
        max_json_redirects: int = 8,
        **kwargs: Any,
    ) -> Response:
        """Send HTTP GET, cache latest response, and return raw response."""
        response = self._request(
            method="GET",
            path=path,
            check_status=check_status,
            **kwargs,
        )
        if follow_json_redirect:
            response = self._follow_json_redirects(
                response=response,
                max_redirects=max_json_redirects,
                check_status=check_status,
                **kwargs,
            )
        self._store_response(response=response)
        return response

    def post(
        self,
        path: str,
        *,
        check_status: bool = True,
        follow_json_redirect: bool = False,
        max_json_redirects: int = 8,
        **kwargs: Any,
    ) -> Response:
        """Send HTTP POST, cache latest response, and return raw response."""
        response = self._request(
            method="POST",
            path=path,
            check_status=check_status,
            **kwargs,
        )
        if follow_json_redirect:
            response = self._follow_json_redirects(
                response=response,
                max_redirects=max_json_redirects,
                check_status=check_status,
                **kwargs,
            )
        self._store_response(response=response)
        return response

    def get_text(
        self,
        path: str,
        *,
        encoding: str | None = None,
        **kwargs: Any,
    ) -> str:
        """Fetch response text from URL/path."""
        response = self.get(path, **kwargs)
        if encoding:
            response.encoding = encoding
            text = response.text
            self.last_body = text
            self.last_document_html = self._normalize_response_body(
                body=text,
                response=response,
            )
            return text
        return self.last_body

    def get_html(
        self,
        path: str,
        *,
        encoding: str | None = None,
        **kwargs: Any,
    ) -> str:
        """Fetch URL/path and return normalized HTML string."""
        self.get_text(path, encoding=encoding, **kwargs)
        return self.last_document_html

    def download(
        self,
        path: str,
        filepath: str | Path,
        *,
        check_status: bool = True,
        chunk_size: int = 8192,
        **kwargs: Any,
    ) -> Path:
        """Download URL/path to local file and return absolute file path."""
        output_path = Path(filepath)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        request_kwargs = dict(kwargs)
        request_kwargs["stream"] = True

        response = self._request(
            method="GET",
            path=path,
            check_status=check_status,
            **request_kwargs,
        )
        with output_path.open("wb") as handle:
            for chunk in response.iter_content(chunk_size=chunk_size):
                if chunk:
                    handle.write(chunk)
        return output_path.resolve()

    def close(self) -> None:
        """Close underlying requests session."""
        self.session.close()

    def __enter__(self) -> HttpClient:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def _request(
        self,
        *,
        method: str,
        path: str,
        check_status: bool,
        **kwargs: Any,
    ) -> Response:
        url = self.resolve_url(path)
        timeout = kwargs.pop("timeout", self.timeout)
        LOGGER.info("HTTP %s %s", method, url)
        response = self.session.request(
            method=method,
            url=url,
            timeout=timeout,
            **kwargs,
        )
        if check_status:
            response.raise_for_status()
        return response

    def _follow_json_redirects(
        self,
        *,
        response: Response,
        max_redirects: int,
        check_status: bool,
        **kwargs: Any,
    ) -> Response:
        current = response
        for _ in range(max(0, max_redirects)):
            redirect_url = self._extract_json_redirect_url(response=current)
            if not redirect_url:
                return current

            timeout = kwargs.get("timeout", self.timeout)
            current = self.session.get(
                redirect_url,
                timeout=timeout,
                allow_redirects=True,
            )
            if check_status:
                current.raise_for_status()
        return current

    def _store_response(self, *, response: Response) -> None:
        body = response.text or ""
        self.last_url = response.url
        self.last_status_code = int(response.status_code)
        self.last_body = body
        self.last_document_html = self._normalize_response_body(
            body=body,
            response=response,
        )

    def _extract_json_redirect_url(self, *, response: Response) -> str | None:
        """Extract redirect URL from JSON response body when present."""
        body = response.text or ""
        if not body:
            return None

        content_type = (response.headers.get("Content-Type") or "").lower()
        maybe_json = "json" in content_type or body.lstrip().startswith("{")
        if not maybe_json:
            return None

        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            return None
        if not isinstance(payload, dict):
            return None

        redirect = payload.get("redirect")
        if not isinstance(redirect, str) or not redirect.strip():
            return None
        return urljoin(response.url or "", redirect.strip())

    def _normalize_response_body(self, *, body: str, response: Response) -> str:
        """Normalize response body to HTML, including JSON-fragment payloads."""
        if not body:
            return ""

        content_type = (response.headers.get("Content-Type") or "").lower()
        maybe_json = "json" in content_type or body.lstrip().startswith("{")
        if not maybe_json:
            return body

        try:
            payload = json.loads(body)
        except json.JSONDecodeError:
            return body

        if not isinstance(payload, dict):
            return body

        # Keep redirect payload untouched; caller can follow redirect separately.
        redirect = payload.get("redirect")
        if isinstance(redirect, str) and redirect.strip():
            return body

        fragment = payload.get("html")
        if not isinstance(fragment, str):
            return body

        title_raw = payload.get("title")
        title = str(title_raw) if title_raw is not None else "Tamarin Interactive"
        source_url = response.url or ""
        return (
            "<!DOCTYPE html>\n"
            "<html>\n"
            "<head>\n"
            "  <meta charset=\"utf-8\">\n"
            f"  <title>{escape(title)}</title>\n"
            "</head>\n"
            "<body>\n"
            f"  <!-- source_url: {escape(source_url)} -->\n"
            "  <div id=\"tamarin-response-root\">\n"
            f"{fragment}\n"
            "  </div>\n"
            "</body>\n"
            "</html>\n"
        )

    @staticmethod
    def _normalize_base_url(base_url: str) -> str:
        candidate = (base_url or "").strip()
        if not candidate:
            raise ValueError("base_url cannot be empty.")

        parsed = urlparse(candidate)
        if not parsed.scheme:
            candidate = f"http://{candidate}"
            parsed = urlparse(candidate)

        if not parsed.scheme or not parsed.netloc:
            raise ValueError(f"Invalid base_url: {base_url!r}")

        normalized_path = parsed.path.rstrip("/")
        return f"{parsed.scheme}://{parsed.netloc}{normalized_path}"
