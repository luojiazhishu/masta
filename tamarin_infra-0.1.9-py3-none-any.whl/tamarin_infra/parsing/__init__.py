"""HTML → structured data parsing layer.

Submodules:
- ``parser``      — BeautifulSoup/lxml facade over the Tamarin interactive HTML.
- ``constraints`` — constraint-system section parsing.
- ``signals``     — proof signal inference and final-state decision.
"""

from __future__ import annotations

from tamarin_infra.parsing import constraints, parser, signals

__all__ = ["constraints", "parser", "signals"]
