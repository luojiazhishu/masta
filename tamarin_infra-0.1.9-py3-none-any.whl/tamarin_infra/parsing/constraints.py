"""Constraint-system parsing extracted from parser.py."""

from __future__ import annotations

import re
from typing import Any

try:
    from bs4 import BeautifulSoup
    from bs4.element import Tag

    _BS4_READY = True
except Exception:  # pragma: no cover - runtime dependency
    BeautifulSoup = Any  # type: ignore[assignment]
    Tag = Any  # type: ignore[assignment]

CONSTRAINT_SECTION_KEYS: tuple[str, ...] = (
    "last",
    "formulas",
    "subterms",
    "equations",
    "subst",
    "conj",
    "lemmas",
    "allowed_cases",
    "solved_formulas",
    "unsolved_constraints",
    "solved_constraints",
)


def parse_constraint_system(soup: BeautifulSoup, page_text: str) -> dict[str, Any]:
    """Parse constraint-system raw text and named sections from *soup* and *page_text*."""
    center = _get_center_pane(soup)

    raw_text = ""
    if center is not None:
        center_text = _clean_text(center.get_text("\n", strip=True))
        raw_text = _extract_section(center_text, "Constraint system")
        section_node = center.select_one("div.preformatted.sequent")
        if isinstance(section_node, Tag):
            raw_text = _clean_text(section_node.get_text("\n", strip=True))
        if not raw_text:
            raw_text = center_text
    if not raw_text:
        raw_text = _extract_section(page_text, "Constraint system") or page_text

    sections_partial = _extract_constraint_sections(_normalize_lines(raw_text))
    sections = {key: sections_partial.get(key, "").strip() for key in CONSTRAINT_SECTION_KEYS}
    return {"sections": sections, "raw_text": raw_text}


def _extract_constraint_sections(lines: list[str]) -> dict[str, str]:
    order = [
        ("last", "last"),
        ("formulas", "formulas"),
        ("subterms", "subterms"),
        ("equations", "equations"),
        ("subst", "subst"),
        ("conj", "conj"),
        ("lemmas", "lemmas"),
        ("allowed_cases", "allowed cases"),
        ("solved_formulas", "solved formulas"),
        ("unsolved_constraints", "unsolved constraints"),
        ("solved_constraints", "solved constraints"),
    ]

    def parse_heading(line: str) -> tuple[str, str] | None:
        lowered = line.strip().lower()
        for key, display in order:
            if lowered == display or lowered.startswith(f"{display}:"):
                rest = line.strip()[len(display):].strip()
                if rest.startswith(":"):
                    rest = rest[1:].strip()
                return key, rest
        return None

    section_lines: dict[str, list[str]] = {}
    current_key: str | None = None
    for line in lines:
        heading = parse_heading(line)
        if heading is not None:
            current_key, rest = heading
            section_lines.setdefault(current_key, [])
            if rest:
                section_lines[current_key].append(rest)
            continue
        if current_key is not None:
            if line.startswith(":"):
                trimmed = line[1:].strip()
                if trimmed:
                    section_lines[current_key].append(trimmed)
            else:
                section_lines[current_key].append(line)

    return {key: "\n".join(section_lines.get(key, [])).strip() for key, _display in order if key in section_lines}


# ---------------------------------------------------------------------------
# Helper copies (needed internally, mirrored from parser.py)
# ---------------------------------------------------------------------------

def _get_center_pane(soup: BeautifulSoup) -> Tag | None:
    center = soup.select_one("[data-testid='constraint-system'], div.ui-layout-center")
    if isinstance(center, Tag):
        return center
    root = soup.select_one("#tamarin-response-root")
    if isinstance(root, Tag):
        return root
    return soup.body if isinstance(soup.body, Tag) else None


def _clean_text(value: str) -> str:
    return re.sub(r"[ \t]+", " ", value or "").strip()


def _normalize_lines(text: str) -> list[str]:
    return [line for line in (_clean_text(part) for part in text.splitlines()) if line]


def _extract_section(text: str, header: str) -> str:
    pattern = re.compile(rf"(?is)\b{re.escape(header)}\b\s*:?\s*(.+?)(?:\n\s*\n(?:[A-Z][^\n]{{0,80}}:)?|\Z)")
    match = pattern.search(text)
    return match.group(0).strip() if match else ""
