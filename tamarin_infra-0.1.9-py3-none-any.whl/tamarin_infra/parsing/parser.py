"""Parsing helpers for Tamarin interactive HTML pages."""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Any, Iterable, Literal, Sequence
from urllib.parse import quote, unquote, urljoin, urlparse

try:
    from bs4 import BeautifulSoup
    from bs4.element import Tag

    _BS4_READY = True
except Exception:  # pragma: no cover - runtime dependency
    BeautifulSoup = Any  # type: ignore[assignment]
    Tag = Any  # type: ignore[assignment]
    _BS4_READY = False


from .constraints import CONSTRAINT_SECTION_KEYS
from .constraints import parse_constraint_system as _parse_constraint_system_impl
from .signals import (
    decide_proof_state as _decide_proof_state,
    infer_lemma_trace_mode as _infer_lemma_trace_mode_impl,
    parse_proof_signals as _parse_proof_signals_impl,
    _extract_proof_script_text,
    _infer_proof_status,
)
PROOF_URL_MARKERS: tuple[str, ...] = ("/main/proof/", "/overview/proof/")
METHOD_URL_MARKERS: tuple[str, ...] = ("/main/method/", "/overview/method/")


@dataclass(slots=True)
class FieldExtraction:
    """Single-field extraction value with optional raw source text."""

    value: str | None
    raw_text: str | None = None


def build_soup(html: str) -> BeautifulSoup:
    """Build BeautifulSoup object with parser fallback."""
    if not _BS4_READY:
        raise RuntimeError("beautifulsoup4 is required for parser functionality.")
    try:
        return BeautifulSoup(html, "lxml")
    except Exception:
        return BeautifulSoup(html, "html.parser")


def parse_interactive_state(
    *,
    html: str,
    fallback_theory: str | None = None,
    fallback_lemma: str | None = None,
    url: str | None = None,
    action_history: Sequence[str] | None = None,
) -> dict[str, Any]:
    """Module-level convenience wrapper for parsing full interactive state."""
    parser = TamarinParser()
    return parser.parse_state(
        html=html,
        fallback_theory=fallback_theory,
        fallback_lemma=fallback_lemma,
        url=url,
        action_history=action_history,
    )


class TamarinParser:
    """Parser facade for extracting structured data from Tamarin pages."""

    def parse_state(
        self,
        *,
        html: str,
        fallback_theory: str | None = None,
        fallback_lemma: str | None = None,
        url: str | None = None,
        action_history: Sequence[str] | None = None,
    ) -> dict[str, Any]:
        """Parse and normalize the simplified state schema used by higher layers."""
        theory = self.parse_theory(html=html) or (fallback_theory or "").strip()
        lemma = self.parse_lemma(html=html, url=url) or (fallback_lemma or "").strip()

        candidates = self.parse_goals(html=html, url=url, absolute_href=False)
        constraint_system = self.parse_constraint_system(html=html)
        subcases = self.parse_subcases(html=html)
        proof = self.parse_proof_state(
            html=html,
            url=url,
            lemma_name=lemma or None,
            candidates=candidates,
            constraint_system=constraint_system,
            subcases=subcases,
        )

        normalized_history = [item.strip() for item in (action_history or ()) if item and item.strip()]
        step = derive_proof_step(url=url, lemma_name=lemma or None, action_history=normalized_history)
        source = derive_proof_source(
            url=url,
            lemma_name=lemma or None,
            step=step,
            action_history=normalized_history,
        )

        return {
            "theory": theory,
            "lemma": lemma,
            "step": step,
            "source": source,
            "url": (url or "").strip(),
            "candidates": [
                {"id": str(item["id"]), "rule": str(item["rule"]), "href": str(item["href"])} for item in candidates
            ],
            "candidate_count": len(candidates),
            "constraint_system": {
                "sections": dict(constraint_system["sections"]),
                "raw_text": str(constraint_system["raw_text"]),
            },
            "subcases": subcases,
            "proof_state": {"state": proof["state"], "result": proof["result"]},
        }

    def parse_theory(self, *, html: str) -> str:
        """Parse current theory name from title/script/text."""
        soup = build_soup(html)
        page_text = _extract_page_text(soup)
        theory_field, _model_field = _extract_current_theory_and_model(soup, page_text)
        return (theory_field.value or "").strip()

    def parse_lemma(self, *, html: str, url: str | None = None) -> str:
        """Parse current lemma name from URL, heading, or script text."""
        soup = build_soup(html)
        page_text = _extract_page_text(soup)
        lemma = _extract_current_lemma(soup, page_text, url=url).value
        return (lemma or "").strip()

    def parse_lemma_type(
        self,
        *,
        html: str,
        lemma_name: str | None = None,
    ) -> Literal["all-traces", "exists-trace", "unknown"]:
        """Infer lemma mode from script-like text fragments."""
        soup = build_soup(html)
        page_text = _extract_page_text(soup)
        return _infer_lemma_trace_mode_impl(
            soup=soup,
            page_text=page_text,
            html=html,
            lemma_name=lemma_name,
        )

    def parse_lemmas(self, *, html: str, url: str | None = None) -> list[str]:
        """Extract lemma names from proof links or script declarations."""
        _ = url
        soup = build_soup(html)
        names: list[str] = []
        seen: set[str] = set()

        for link in soup.select(
            "#proof a[href*='/main/proof/'], a[href*='/main/proof/'], "
            "#proof a[href*='/overview/proof/'], a[href*='/overview/proof/']"
        ):
            href = _clean_attr(link.get("href"))
            lemma = _lemma_name_from_proof_href(href)
            if lemma and lemma not in seen:
                names.append(lemma)
                seen.add(lemma)

        if names:
            return names

        page_text = _extract_page_text(soup)
        for match in re.finditer(r"(?im)^\s*(?:all-traces|exists-trace)?\s*lemma\s+([^\s\[:]+)", page_text):
            lemma = match.group(1).strip()
            if lemma and lemma not in seen:
                names.append(lemma)
                seen.add(lemma)
        return names

    def parse_goals(
        self,
        *,
        html: str,
        url: str | None = None,
        absolute_href: bool = False,
    ) -> list[dict[str, Any]]:
        """Parse candidate proof methods and case-like links."""
        soup = build_soup(html)
        page_text = _extract_page_text(soup)
        center = _get_center_pane(soup)
        base_url = url if absolute_href else None

        candidates: list[dict[str, Any]] = []
        if center is not None:
            candidates.extend(_extract_method_link_candidates(center=center, base_url=base_url))
            candidates.extend(_extract_case_candidates(center=center, base_url=base_url))
            if not candidates:
                candidates.extend(_extract_method_text_candidates(center=center, base_url=base_url))

        if not candidates:
            candidates = _extract_candidate_blocks_from_text(page_text, base_url=base_url)

        return _dedupe_candidates(candidates)

    def parse_constraint_system(self, *, html: str) -> dict[str, Any]:
        """Parse constraint-system raw text and named sections."""
        soup = build_soup(html)
        page_text = _extract_page_text(soup)
        return _parse_constraint_system_impl(soup, page_text)

    def parse_subcases(self, *, html: str) -> str:
        """Parse subcases text like `0 sub-case(s)`."""
        soup = build_soup(html)
        page_text = _extract_page_text(soup)
        for heading in soup.select("h3"):
            text = _clean_text(heading.get_text(" ", strip=True))
            if text and "sub-case(s)" in text.lower():
                return text
        match = re.search(r"(?i)\b(\d+\s+sub-case\(s\))\b", page_text)
        return _clean_text(match.group(1)) if match else ""

    def parse_download_link(self, *, html: str, base_url: str | None = None) -> str | None:
        """Parse exported `.spthy` download link."""
        soup = build_soup(html)
        fallback_url: str | None = None
        for link in soup.select("a[href]"):
            href = _clean_attr(link.get("href"))
            if not href:
                continue
            text = _clean_text(link.get_text(" ", strip=True)).lower()
            href_lower = href.lower()
            resolved = _join_url(base_url, href)
            if text == "download":
                return resolved
            if href_lower.endswith(".spthy"):
                return resolved
            if "download" in text or "download" in href_lower:
                fallback_url = fallback_url or resolved
        return fallback_url

    def parse_proof_signals(
        self,
        *,
        html: str,
        url: str | None = None,
        lemma_name: str | None = None,
        candidates: Sequence[dict[str, Any]] | None = None,
        constraint_system: dict[str, Any] | None = None,
        subcases: str | None = None,
    ) -> dict[str, Any]:
        """Parse semantic signals used for proof-state decisions."""
        soup = build_soup(html)
        page_text = _extract_page_text(soup)
        parsed_candidates = list(candidates) if candidates is not None else self.parse_goals(html=html, url=url)
        parsed_constraints = constraint_system if constraint_system is not None else self.parse_constraint_system(html=html)
        parsed_subcases = subcases if subcases is not None else self.parse_subcases(html=html)

        proof_raw_text = _extract_proof_state_raw_text(soup=soup, page_text=page_text)

        return _parse_proof_signals_impl(
            soup=soup,
            page_text=page_text,
            html=html,
            url=url,
            lemma_name=lemma_name,
            candidates=parsed_candidates,
            constraint_system=parsed_constraints,
            subcases=parsed_subcases or "",
            proof_raw_text=proof_raw_text,
            proof_script_text=_extract_proof_script_text(soup),
        )

    def parse_proof_state(
        self,
        *,
        html: str,
        url: str | None = None,
        lemma_name: str | None = None,
        candidates: Sequence[dict[str, Any]] | None = None,
        constraint_system: dict[str, Any] | None = None,
        subcases: str | None = None,
    ) -> dict[str, Any]:
        """Parse proof summary and return state/result plus decision signals."""
        soup = build_soup(html)
        page_text = _extract_page_text(soup)
        raw_text = _extract_proof_state_raw_text(soup=soup, page_text=page_text)
        signals = self.parse_proof_signals(
            html=html,
            url=url,
            lemma_name=lemma_name,
            candidates=candidates,
            constraint_system=constraint_system,
            subcases=subcases,
        )
        state, result = _decide_proof_state(signals)
        return {
            "state": state,
            "result": result,
            "status": _infer_proof_status(raw_text) or "",
            "summary": _first_non_empty_line(raw_text) or "",
            "goals": _extract_goal_lines(raw_text),
            "signals": signals,
        }


def derive_proof_step(*, url: str | None, lemma_name: str | None, action_history: Sequence[str]) -> int:
    """Derive proof step from URL depth and action history length."""
    url_step = _derive_step_from_url(url=url, lemma_name=lemma_name)
    history_step = 1 + len(action_history) if action_history else 1
    return max(1, url_step, history_step)


def derive_proof_source(
    *,
    url: str | None,
    lemma_name: str | None,
    step: int,
    action_history: Sequence[str],
) -> str:
    """Derive source text for current state.

    If local action history is unavailable, URL token inference is used as fallback.
    """
    lemma_text = (lemma_name or "").strip()
    if step <= 1:
        return lemma_text
    if action_history:
        index = min(step - 2, len(action_history) - 1)
        return action_history[index]
    return _extract_method_token_from_url(url=url, lemma_name=lemma_name) or lemma_text


def infer_lemma_trace_mode(
    *,
    soup: BeautifulSoup,
    page_text: str,
    html: str,
    lemma_name: str | None,
) -> Literal["all-traces", "exists-trace", "unknown"]:
    """Infer lemma type from script fragments and page text.

    Re-exported from signals.py for backward compatibility.
    """
    return _infer_lemma_trace_mode_impl(
        soup=soup,
        page_text=page_text,
        html=html,
        lemma_name=lemma_name,
    )


def resolve_download_url(*, html: str, base_url: str | None = None) -> str | None:
    """Compatibility helper for parsing download URL."""
    return TamarinParser().parse_download_link(html=html, base_url=base_url)


def extract_lemma_names(*, html: str, url: str | None = None) -> list[str]:
    """Compatibility helper for parsing lemma names."""
    return TamarinParser().parse_lemmas(html=html, url=url)


def resolve_theory_url(*, html: str, theory_name: str, base_url: str | None) -> str | None:
    """Resolve theory page URL from index/list links."""
    soup = build_soup(html)
    target = theory_name.strip().lower()
    if not target:
        return None
    for row in soup.select("table tbody tr"):
        link = row.select_one("td a[href]")
        if not isinstance(link, Tag):
            continue
        text = _clean_text(link.get_text(" ", strip=True)).lower()
        if text == target:
            href = _clean_attr(link.get("href"))
            return _join_url(base_url, href) if href else None
    for link in soup.select("a[href]"):
        text = _clean_text(link.get_text(" ", strip=True)).lower()
        if text == target:
            href = _clean_attr(link.get("href"))
            return _join_url(base_url, href) if href else None
    return None


def resolve_lemma_proof_url(*, html: str, lemma_name: str, base_url: str | None) -> str | None:
    """Resolve lemma proof URL by matching `/proof/<lemma>` links."""
    target = lemma_name.strip().lower()
    if not target:
        return None
    soup = build_soup(html)
    for link in soup.select("a[href]"):
        href = _clean_attr(link.get("href"))
        lemma = _lemma_name_from_proof_href(href)
        if lemma and lemma.lower() == target:
            return _join_url(base_url, href)
    encoded = quote(lemma_name.strip(), safe="")
    for link in soup.select("a[href]"):
        href = _clean_attr(link.get("href"))
        if href and f"/proof/{encoded}" in href:
            return _join_url(base_url, href)
    return None


def resolve_candidate_action_url(*, html: str, candidate_id: str, base_url: str | None) -> str | None:
    """Resolve action URL for one candidate id by link text/href matching."""
    target = candidate_id.strip().lower()
    if not target:
        return None
    soup = build_soup(html)
    for link in soup.select("a[href]"):
        href = _clean_attr(link.get("href"))
        text = _clean_text(link.get_text(" ", strip=True)).lower()
        if not href:
            continue
        if target == text or target in href.lower():
            return _join_url(base_url, href)
    return None


def _extract_current_theory_and_model(soup: BeautifulSoup, page_text: str) -> tuple[FieldExtraction, FieldExtraction]:
    theory: str | None = None
    model_name: str | None = None
    title_text = _clean_text((soup.title.get_text() if soup.title else ""))
    if title_text:
        match = re.search(r"(?i)\btheory\s*:\s*(.+)$", title_text)
        if match:
            theory = _clean_text(match.group(1))
    script = soup.select_one("#proof")
    if isinstance(script, Tag):
        script_text = _clean_text(script.get_text("\n", strip=True))
        script_match = re.search(r"(?im)^\s*theory\s+([^\s]+)\s+begin\b", script_text)
        if script_match and not theory:
            theory = _clean_text(script_match.group(1))
    theory_match = _match_named_value(page_text, name_patterns=("theory", "model", "current model", "current theory"))
    if theory_match.value and not theory:
        theory = theory_match.value
    model_match = _match_named_value(page_text, name_patterns=("model", "current model", "protocol model"))
    if model_match.value:
        model_name = model_match.value
    return FieldExtraction(theory), FieldExtraction(model_name)


def _extract_current_lemma(soup: BeautifulSoup, page_text: str, *, url: str | None) -> FieldExtraction:
    lemma = extract_lemma_from_proof_url(url)
    if not lemma:
        center = _get_center_pane(soup)
        if center is not None:
            center_text = _clean_text(center.get_text("\n", strip=True))
            heading_match = re.search(r"(?im)^\s*lemma\s*:\s*([^\s]+)\s*$", center_text)
            if heading_match:
                lemma = _clean_text(heading_match.group(1))
    if not lemma:
        lemma_match = _match_named_value(page_text, name_patterns=("lemma", "current lemma", "selected lemma"))
        lemma = lemma_match.value
    if not lemma:
        lemma_decl = _match_lemma_declaration(page_text)
        lemma = lemma_decl.value
    return FieldExtraction(lemma)


def extract_lemma_from_proof_url(url: str | None) -> str | None:
    """Extract lemma name from a proof URL path."""
    if not url:
        return None
    path = urlparse(url).path
    for marker in PROOF_URL_MARKERS:
        if marker in path:
            tail = path.split(marker, 1)[1]
            lemma = unquote(tail.split("/", 1)[0]).strip()
            return lemma or None
    return None


def _extract_method_link_candidates(center: Tag, *, base_url: str | None) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for link in center.select("div.preformatted.methods a.proof-method[href], a.proof-method[href]"):
        href = _clean_attr(link.get("href"))
        rule = _clean_text(link.get_text(" ", strip=True))
        if not href or not rule or "/method/" not in href.lower():
            continue
        items.append({"id": _stable_rule_hash(rule), "rule": rule, "href": _join_url(base_url, href), "kind": "proof_method"})
    return items


def _extract_case_candidates(center: Tag, *, base_url: str | None) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    for link in center.select("a[href]"):
        href = _clean_attr(link.get("href"))
        text = _clean_text(link.get_text(" ", strip=True))
        if not href or not text:
            continue
        lowered_href = href.lower()
        if "/case/" not in lowered_href and "/subcase/" not in lowered_href:
            continue
        if text.lower() in {"download", "index"}:
            continue
        items.append({"id": _stable_rule_hash(text), "rule": text, "href": _join_url(base_url, href), "kind": "case"})
    return items


def _extract_method_text_candidates(center: Tag, *, base_url: str | None) -> list[dict[str, Any]]:
    center_text = _clean_text(center.get_text("\n", strip=True))
    method_lines = _extract_method_lines(center_text)
    method_links = _extract_method_links(center, base_url=base_url)
    items: list[dict[str, Any]] = []
    for line in method_lines:
        rule = _extract_method_name(line)
        if rule:
            items.append(
                {"id": _stable_rule_hash(rule), "rule": rule, "href": method_links.get(rule.lower(), ""), "kind": "proof_method"}
            )
    return items


def _extract_candidate_blocks_from_text(page_text: str, *, base_url: str | None) -> list[dict[str, Any]]:
    _ = base_url
    blocks = [m.group(0).strip() for m in re.finditer(r"(?is)(?:candidate|method)\s+[\w\-.]+.*?(?:\n\s*\n|\Z)", page_text)]
    items: list[dict[str, Any]] = []
    for index, block in enumerate(blocks):
        first = _first_non_empty_line(block) or f"Candidate {index}"
        rule = _extract_method_name(first)
        items.append({"id": _stable_rule_hash(rule), "rule": rule, "href": "", "kind": "candidate"})
    return items


def _dedupe_candidates(candidates: Sequence[dict[str, Any]]) -> list[dict[str, Any]]:
    deduped: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for item in candidates:
        rule = str(item.get("rule", "")).strip()
        href = str(item.get("href", "")).strip()
        if not rule:
            continue
        key = (rule, href)
        if key in seen:
            continue
        seen.add(key)
        deduped.append({"id": str(item.get("id") or _stable_rule_hash(rule)), "rule": rule, "href": href, "kind": item.get("kind", "")})
    return deduped


def _extract_method_lines(center_text: str) -> list[str]:
    start = center_text.lower().find("applicable proof methods")
    if start < 0:
        return []
    end = center_text.lower().find("constraint system", start)
    section = center_text[start:end] if end > start else center_text[start:]
    return [line for line in _normalize_lines(section) if re.match(r"^[0-9A-Za-z]\.\s+", line)]


def _extract_method_links(center: Tag, *, base_url: str | None) -> dict[str, str]:
    links: dict[str, str] = {}
    for link in center.select("a[href]"):
        text = _clean_text(link.get_text(" ", strip=True))
        href = _clean_attr(link.get("href"))
        if not text or not href:
            continue
        if text.lower() in {"index", "download", "actions", "options"}:
            continue
        links[text.lower()] = _join_url(base_url, href)
    return links



def _extract_proof_state_raw_text(*, soup: BeautifulSoup, page_text: str) -> str:
    center = _get_center_pane(soup)
    if center is not None:
        text = _clean_text(center.get_text("\n", strip=True))
        if text:
            return text
    return _extract_section(page_text, "Proof state") or page_text


def _extract_goal_lines(raw_text: str) -> list[str]:
    return [line for line in _normalize_lines(raw_text) if line.lower().startswith(("goal", "- goal", "* goal"))]



def _derive_step_from_url(*, url: str | None, lemma_name: str | None) -> int:
    if not url:
        return 1
    path = urlparse(url).path
    lowered = path.lower()
    lemma_lower = (lemma_name or "").strip().lower()
    for marker in PROOF_URL_MARKERS:
        if marker in lowered:
            return 1
    for marker in METHOD_URL_MARKERS:
        pos = lowered.find(marker)
        if pos < 0:
            continue
        parts = [p for p in path[pos + len(marker):].split("/") if p]
        if parts and lemma_lower and parts[0].strip().lower() == lemma_lower:
            parts = parts[1:]
        return 1 + max(1, len(parts))
    if "/method/" in lowered:
        return 2
    return 1


def _extract_method_token_from_url(*, url: str | None, lemma_name: str | None) -> str:
    if not url:
        return ""
    path = urlparse(url).path
    lowered = path.lower()
    lemma_lower = (lemma_name or "").strip().lower()
    for marker in METHOD_URL_MARKERS:
        pos = lowered.find(marker)
        if pos < 0:
            continue
        parts = [p for p in path[pos + len(marker):].split("/") if p]
        if parts and lemma_lower and parts[0].strip().lower() == lemma_lower:
            parts = parts[1:]
        if parts:
            return unquote(parts[-1]).strip()
    return ""


def _lemma_name_from_proof_href(href: str) -> str | None:
    path = urlparse(href).path
    for marker in PROOF_URL_MARKERS:
        if marker in path:
            tail = path.split(marker, 1)[1]
            lemma = unquote(tail.split("/", 1)[0]).strip()
            return lemma or None
    return None



def _extract_page_text(soup: BeautifulSoup) -> str:
    return _clean_text(soup.get_text("\n", strip=True))


def _get_center_pane(soup: BeautifulSoup) -> Tag | None:
    center = soup.select_one("[data-testid='constraint-system'], div.ui-layout-center")
    if isinstance(center, Tag):
        return center
    root = soup.select_one("#tamarin-response-root")
    if isinstance(root, Tag):
        return root
    return soup.body if isinstance(soup.body, Tag) else None


def _extract_section(text: str, header: str) -> str:
    pattern = re.compile(rf"(?is)\b{re.escape(header)}\b\s*:?\s*(.+?)(?:\n\s*\n(?:[A-Z][^\n]{{0,80}}:)?|\Z)")
    match = pattern.search(text)
    return match.group(0).strip() if match else ""



def _stable_rule_hash(rule: str) -> str:
    return hashlib.sha1((rule or "").encode("utf-8")).hexdigest()


def _extract_method_name(line: str) -> str:
    match = re.match(r"^[0-9A-Za-z]\.\s+(.+)$", line.strip())
    return match.group(1).strip() if match else line.strip()


def _clean_text(value: str) -> str:
    return re.sub(r"[ \t]+", " ", value or "").strip()


def _clean_attr(value: object) -> str:
    return value.strip() if isinstance(value, str) else ""


def _join_url(base_url: str | None, href: str) -> str:
    return urljoin(base_url, href) if base_url else href


def _normalize_lines(text: str) -> list[str]:
    return [line for line in (_clean_text(part) for part in text.splitlines()) if line]


def _first_non_empty_line(text: str) -> str | None:
    lines = _normalize_lines(text)
    return lines[0] if lines else None


def _match_named_value(text: str, *, name_patterns: Iterable[str]) -> FieldExtraction:
    escaped = "|".join(re.escape(item) for item in name_patterns)
    match = re.search(rf"(?im)^\s*(?:{escaped})\s*[:=]\s*(.+?)\s*$", text)
    if not match:
        return FieldExtraction(None)
    return FieldExtraction(_clean_text(match.group(1)) or None, match.group(0).strip())


def _match_lemma_declaration(text: str) -> FieldExtraction:
    match = re.search(r"(?im)^\s*(?:all-traces|exists-trace)?\s*lemma\s+([^\s\[:]+)", text)
    if not match:
        return FieldExtraction(None)
    return FieldExtraction(_clean_text(match.group(1)) or None, match.group(0).strip())
