"""Proof signal inference extracted from parser.py."""

from __future__ import annotations

import re
from typing import Any, Literal, Sequence

try:
    from bs4 import BeautifulSoup
    from bs4.element import Tag

    _BS4_READY = True
except Exception:  # pragma: no cover - runtime dependency
    BeautifulSoup = Any  # type: ignore[assignment]
    Tag = Any  # type: ignore[assignment]


def parse_proof_signals(
    *,
    soup: BeautifulSoup,
    page_text: str,
    html: str,
    url: str | None,
    lemma_name: str | None,
    candidates: Sequence[dict[str, Any]],
    constraint_system: dict[str, Any],
    subcases: str,
    proof_raw_text: str,
    proof_script_text: str,
) -> dict[str, Any]:
    """Compute the 13 boolean signals used for proof-state decisions."""
    parser_status = (_infer_proof_status(proof_raw_text) or "").strip().lower()
    lemma_trace_mode = infer_lemma_trace_mode(
        soup=soup,
        page_text=page_text,
        html=html,
        lemma_name=lemma_name,
    )
    sections = constraint_system.get("sections", {}) if isinstance(constraint_system, dict) else {}
    unsolved = str(sections.get("unsolved_constraints", "")).strip()
    raw_constraint_text = str(constraint_system.get("raw_text", "")).strip()
    signal_text = _build_signal_text(
        html=html,
        page_text=page_text,
        constraint_raw_text=raw_constraint_text,
        proof_raw_text=proof_raw_text,
        proof_script_text=proof_script_text,
    )

    has_candidates = len(candidates) > 0
    has_unsolved_constraints = bool(unsolved)
    has_open_subcases = _has_open_subcases(subcases or "")
    has_attack_signal = _contains_any(signal_text, ("attack found", "counterexample", "counter-example", "falsified"))
    has_trace_found = _contains_any(signal_text, ("trace found", "found trace", "witness trace"))
    has_bad_marker = _contains_any(signal_text, ("hl_bad", " class=\"bad", " class='bad", "bad branch", "bad case"))
    has_solved_marker = _contains_any(signal_text, ("constraint system is solved", " solved //", "\nsolved\n", " solved "))
    has_success_marker = _contains_any(signal_text, ("qed", "proved", "proven", "verification successful", "no attack found"))
    has_terminal_marker = has_solved_marker or has_success_marker or parser_status in {"proved", "finished", "failed"}
    has_active_constraint_system = bool(raw_constraint_text) and not has_solved_marker
    has_pending_work = has_candidates or has_unsolved_constraints or has_open_subcases or has_active_constraint_system

    return {
        "lemma_trace_mode": lemma_trace_mode,
        "parser_status": parser_status,
        "has_candidates": has_candidates,
        "has_unsolved_constraints": has_unsolved_constraints,
        "has_open_subcases": has_open_subcases,
        "has_active_constraint_system": has_active_constraint_system,
        "has_pending_work": has_pending_work,
        "has_attack_signal": has_attack_signal,
        "has_trace_found": has_trace_found,
        "has_bad_marker": has_bad_marker,
        "has_solved_marker": has_solved_marker,
        "has_success_marker": has_success_marker,
        "has_terminal_marker": has_terminal_marker,
    }


def decide_proof_state(
    signals: dict[str, Any],
) -> tuple[Literal["finished", "unfinished"], Literal["verified", "falsified - found trace", ""]]:
    """Decision tree: map proof signals to (state, result)."""
    mode = str(signals.get("lemma_trace_mode", "unknown"))
    has_pending = bool(signals.get("has_pending_work", False))
    has_attack = bool(signals.get("has_attack_signal", False))
    has_trace = bool(signals.get("has_trace_found", False))
    has_bad = bool(signals.get("has_bad_marker", False))
    has_terminal = bool(signals.get("has_terminal_marker", False))
    status = str(signals.get("parser_status", "")).strip().lower()

    if mode == "all-traces" and has_trace and has_bad and has_terminal:
        return "finished", "falsified - found trace"
    if has_attack:
        return "finished", "falsified - found trace"
    if mode == "exists-trace" and has_trace and has_terminal:
        return "finished", "verified"
    if mode == "all-traces" and has_trace and has_terminal:
        return "finished", "falsified - found trace"
    if has_pending:
        return "unfinished", ""
    if has_terminal and not has_bad and not has_attack:
        return "finished", "verified"
    if status in {"open", "active", "searching"}:
        return "unfinished", ""
    return "finished", "verified"


def infer_lemma_trace_mode(
    *,
    soup: BeautifulSoup,
    page_text: str,
    html: str,
    lemma_name: str | None,
) -> Literal["all-traces", "exists-trace", "unknown"]:
    """Infer lemma type from script fragments and page text."""
    combined = _build_signal_text(
        html=html,
        page_text=page_text,
        constraint_raw_text="",
        proof_raw_text="",
        proof_script_text=_extract_proof_script_text(soup),
    )
    lemma = (lemma_name or "").strip()
    lemma_pattern = re.escape(lemma) if lemma else r"[^\s:]+"
    for pattern in (
        rf"(?im)\bexists-trace\s+lemma\s+{lemma_pattern}\b",
        rf"(?im)\blemma\s+{lemma_pattern}\b[^\n]{{0,200}}\bexists-trace\b",
        r"(?im)\bexists-trace\s+lemma\b",
    ):
        if re.search(pattern, combined):
            return "exists-trace"
    for pattern in (
        rf"(?im)\ball-traces\s+lemma\s+{lemma_pattern}\b",
        rf"(?im)\blemma\s+{lemma_pattern}\b[^\n]{{0,200}}\ball-traces\b",
        r"(?im)\ball-traces\s+lemma\b",
    ):
        if re.search(pattern, combined):
            return "all-traces"
    return "unknown"


def _infer_proof_status(raw_text: str) -> str | None:
    lowered = raw_text.lower()
    if not lowered:
        return None
    if "qed" in lowered or "proved" in lowered or "proven" in lowered:
        return "proved"
    if "open goal" in lowered or "unproven" in lowered or "remaining goal" in lowered:
        return "open"
    if "failed" in lowered or "contradiction" in lowered:
        return "failed"
    if "searching" in lowered or "processing" in lowered:
        return "searching"
    if "lemma:" in lowered:
        return "active"
    return "unknown"


def _contains_any(text: str, needles: Sequence[str]) -> bool:
    lowered = text.lower()
    return any(needle.lower() in lowered for needle in needles)


def _has_open_subcases(subcases: str) -> bool:
    text = (subcases or "").strip().lower()
    if not text:
        return False
    match = re.search(r"(\d+)\s+sub-case\(s\)", text)
    if not match:
        return True
    try:
        return int(match.group(1)) > 0
    except ValueError:
        return True


def _build_signal_text(*, html: str, page_text: str, constraint_raw_text: str, proof_raw_text: str, proof_script_text: str) -> str:
    return "\n".join(part.lower() for part in (html, page_text, constraint_raw_text, proof_raw_text, proof_script_text) if part)


def _extract_proof_script_text(soup: BeautifulSoup) -> str:
    fragments: list[str] = []
    for selector in ("#proof", "div.ui-layout-west", "div.ui-layout-center"):
        node = soup.select_one(selector)
        if isinstance(node, Tag):
            text = _clean_text(node.get_text("\n", strip=True))
            if text:
                fragments.append(text)
    return "\n".join(fragments)


# ---------------------------------------------------------------------------
# Helper copy (needed internally, mirrored from parser.py)
# ---------------------------------------------------------------------------

def _clean_text(value: str) -> str:
    return re.sub(r"[ \t]+", " ", value or "").strip()
