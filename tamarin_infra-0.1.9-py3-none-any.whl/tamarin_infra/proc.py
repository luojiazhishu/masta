"""Process management for local and remote Tamarin interactive runtimes."""

from __future__ import annotations

import os
import re
import select
import shlex
import socket
import subprocess
import threading
import time
import uuid
from typing import Any, Mapping, Sequence

try:
    import paramiko
except ImportError:  # pragma: no cover - runtime dependent
    paramiko = None


def _wait_for_tcp_port(host: str, port: int, timeout: float, poll_interval: float = 0.25) -> bool:
    """Wait until a TCP endpoint becomes reachable."""
    if timeout <= 0:
        return False
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=min(1.0, poll_interval)):
                return True
        except OSError:
            time.sleep(poll_interval)
    return False


def _normalize_extra_args(extra_args: Sequence[str] | str | None) -> list[str]:
    """Convert optional argument input into a list of strings."""
    if extra_args is None:
        return []
    if isinstance(extra_args, str):
        return [extra_args]
    return [str(item) for item in extra_args]


class BaseTamarinProc:
    """Shared abstraction for Tamarin process-management backends."""

    def __init__(
        self,
        *,
        mode: str,
        workdir: str = ".",
        host: str = "127.0.0.1",
        port: int = 3001,
        timeout: float = 30.0,
        tamarin_binary: str = "tamarin-prover",
    ) -> None:
        self.mode = mode
        self.workdir = workdir
        self.host = host
        self.port = int(port)
        self.timeout = float(timeout)
        self.tamarin_binary = tamarin_binary

        self.pid: str | None = None
        self.running: bool = False

    def execute(self, command: str, **kwargs: Any) -> Any:
        """Execute a command in the backend runtime."""
        raise NotImplementedError

    def start(self, *args: Any, **kwargs: Any) -> None:
        """Start backend runtime."""
        raise NotImplementedError

    def stop(self) -> None:
        """Stop backend runtime."""
        raise NotImplementedError

    def _probe_alive(self) -> bool:
        """Return True if the underlying process is alive. Subclass must override."""
        return False

    def is_running(self) -> bool:
        """Template: probe liveness, sync state, clear pid on death."""
        alive = self._probe_alive()
        self.running = alive
        if not alive:
            self.pid = None
        return alive

    def build_interactive_command(
        self,
        workdir: str,
        port: int,
        extra_args: list[str] | None = None,
    ) -> list[str]:
        """Build command list for `tamarin-prover interactive` launch."""
        command = [self.tamarin_binary, "interactive", f"--port={int(port)}"]
        if extra_args:
            command.extend(extra_args)
        command.append(workdir.strip() or ".")
        return command

    def _parse_start_kwargs(self, **kwargs: Any) -> dict[str, Any]:
        """Extract and normalize common start() parameters."""
        return {
            "workdir": str(kwargs.get("workdir", self.workdir)).strip() or ".",
            "port": int(kwargs.get("port", self.port)),
            "timeout": float(kwargs.get("timeout", self.timeout)),
            "extra_args": _normalize_extra_args(kwargs.get("extra_args")),
        }


class LocalTamarinProc(BaseTamarinProc):
    """Manage local `tamarin-prover interactive` process lifecycle."""

    def __init__(
        self,
        *,
        host: str = "127.0.0.1",
        port: int = 3001,
        workdir: str = ".",
        timeout: float = 30.0,
        tamarin_binary: str = "tamarin-prover",
        env: Mapping[str, str] | None = None,
        log_file: str | None = None,
    ) -> None:
        super().__init__(
            mode="local",
            workdir=workdir,
            host=host,
            port=port,
            timeout=timeout,
            tamarin_binary=tamarin_binary,
        )
        self.env = dict(env) if env is not None else None
        self.log_file = log_file
        self._process: subprocess.Popen[bytes] | None = None
        self._log_handle: Any | None = None

    def execute(self, command: str, **kwargs: Any) -> subprocess.CompletedProcess[str]:
        """Execute a local shell command and return result."""
        timeout = float(kwargs.get("timeout", self.timeout))
        completed = subprocess.run(
            command,
            shell=True,
            cwd=self.workdir,
            env=self._build_env(),
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        if completed.returncode != 0:
            raise RuntimeError(
                f"Local command failed (exit={completed.returncode}): {completed.stderr.strip()}"
            )
        return completed

    def start(self, *args: Any, **kwargs: Any) -> None:
        """Launch local Tamarin interactive process."""
        if self.is_running():
            return

        parsed = self._parse_start_kwargs(**kwargs)
        target_workdir = parsed["workdir"]
        target_port = parsed["port"]
        startup_timeout = parsed["timeout"]
        extra_args = parsed["extra_args"]
        wait_for_port = bool(kwargs.get("wait_for_port", True))
        log_file = kwargs.get("log_file", self.log_file)

        command = self.build_interactive_command(
            workdir=target_workdir,
            port=target_port,
            extra_args=extra_args,
        )
        stdout_target, stderr_target = self._build_output_targets(log_file, target_workdir)

        try:
            process = subprocess.Popen(
                command,
                cwd=target_workdir,
                env=self._build_env(),
                stdout=stdout_target,
                stderr=stderr_target,
            )
        except FileNotFoundError as exc:
            self._close_log_handle()
            missing_target = getattr(exc, "filename", "") or ""
            if str(missing_target).strip() == target_workdir:
                raise RuntimeError(
                    f"Workdir directory not found: {target_workdir}"
                ) from exc
            raise RuntimeError(
                f"Could not find executable '{self.tamarin_binary}'. Check installation and PATH."
            ) from exc
        except OSError as exc:
            self._close_log_handle()
            raise RuntimeError(f"Failed to launch local Tamarin process: {exc}") from exc

        self.workdir = target_workdir
        self.port = target_port
        self._process = process
        self.pid = str(process.pid)
        self.running = True

        if process.poll() is not None:
            self.running = False
            self.pid = None
            self._process = None
            self._close_log_handle()
            raise RuntimeError("Local Tamarin process exited immediately after start.")

        if wait_for_port and not _wait_for_tcp_port(self.host, self.port, startup_timeout):
            self.stop()
            raise RuntimeError(f"Local UI port is not reachable: {self.host}:{self.port}")

    def stop(self) -> None:
        """Stop local Tamarin process."""
        process = self._process
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5.0)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(timeout=5.0)

        self._process = None
        self.pid = None
        self.running = False
        self._close_log_handle()

    def _probe_alive(self) -> bool:
        """Return True when local subprocess is still alive."""
        process = self._process
        if process is None:
            return False
        return process.poll() is None

    def _build_env(self) -> dict[str, str] | None:
        if self.env is None:
            return None
        merged = dict(os.environ)
        merged.update(self.env)
        return merged

    def _build_output_targets(self, log_file: str | None, base_dir: str) -> tuple[Any, Any]:
        self._close_log_handle()
        if not log_file:
            return subprocess.DEVNULL, subprocess.DEVNULL
        resolved = log_file
        if not os.path.isabs(resolved):
            resolved = os.path.join(base_dir, resolved)
        self._log_handle = open(resolved, "ab")
        return self._log_handle, self._log_handle

    def _close_log_handle(self) -> None:
        if self._log_handle is None:
            return
        try:
            self._log_handle.flush()
            self._log_handle.close()
        except OSError:
            pass
        finally:
            self._log_handle = None


class RemoteTamarinProc(BaseTamarinProc):
    """Manage remote SSH Tamarin process and localhost port forwarding."""

    def __init__(
        self,
        *,
        host: str,
        user: str,
        ssh_port: int = 22,
        port: int = 3001,
        workdir: str = ".",
        timeout: float = 30.0,
        tamarin_binary: str = "tamarin-prover",
        password: str | None = None,
        key_filename: str | None = None,
        look_for_keys: bool = True,
        allow_agent: bool = True,
        remote_ui_host: str = "127.0.0.1",
        local_forward_host: str = "127.0.0.1",
        local_forward_port: int = 0,
        remote_log_file: str = "tamarin_interactive.log",
    ) -> None:
        normalized_workdir = (workdir or "").strip()
        if not normalized_workdir or normalized_workdir == ".":
            normalized_workdir = f"/tmp/tamarin-{uuid.uuid4().hex}"
            self._workdir_owned = True
        else:
            self._workdir_owned = False

        super().__init__(
            mode="remote",
            workdir=normalized_workdir,
            host=host,
            port=port,
            timeout=timeout,
            tamarin_binary=tamarin_binary,
        )
        self.user = user
        self.ssh_port = int(ssh_port)
        self.password = password
        self.key_filename = key_filename
        self.look_for_keys = look_for_keys
        self.allow_agent = allow_agent

        self.remote_ui_host = remote_ui_host
        self.remote_ui_port = int(port)
        self.remote_log_file = remote_log_file

        self.local_forward_host = local_forward_host
        self.local_forward_port = int(local_forward_port)
        self.forwarded_base_url: str | None = None

        self.ssh_client: Any | None = None
        self.remote_pid: str | None = None
        self.last_command: str | None = None
        self.last_error: str | None = None

        self._tunnel_listener: socket.socket | None = None
        self._tunnel_thread: threading.Thread | None = None
        self._tunnel_stop_event: threading.Event | None = None
        self._tunnel_workers: set[threading.Thread] = set()
        self._tunnel_lock = threading.Lock()

    def connect(self) -> None:
        """Open SSH connection for remote control."""
        if self.ssh_client is not None:
            transport = self.ssh_client.get_transport()
            if transport is not None and transport.is_active():
                return

        if paramiko is None:
            raise RuntimeError("paramiko is not installed. Remote mode requires paramiko.")

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(
            hostname=self.host,
            port=self.ssh_port,
            username=self.user,
            password=self.password,
            key_filename=self.key_filename,
            look_for_keys=self.look_for_keys,
            allow_agent=self.allow_agent,
            timeout=self.timeout,
        )
        self.ssh_client = client
        self.last_error = None

    def disconnect(self) -> None:
        """Close local tunnel and SSH session."""
        self._close_tunnel()
        if self._workdir_owned and self.ssh_client is not None:
            try:
                self.execute(
                    f"rm -rf {shlex.quote(self.workdir)} >/dev/null 2>&1 || true"
                )
            except Exception:
                pass
        if self.ssh_client is not None:
            self.ssh_client.close()
        self.ssh_client = None
        self.forwarded_base_url = None

    def ensure_workdir(self) -> str:
        """Ensure the remote working directory exists; return its absolute path."""
        self.connect()
        self.execute(
            f"mkdir -p {shlex.quote(self.workdir)}",
            check_exit=True,
        )
        return self.workdir

    def upload(self, local_path: str, remote_name: str | None = None) -> str:
        """Upload a local file into the remote working directory and return remote path."""
        source = os.path.abspath(local_path)
        if not os.path.isfile(source):
            raise FileNotFoundError(f"Local file not found: {source}")

        self.connect()
        self.ensure_workdir()
        if self.ssh_client is None:
            raise RuntimeError("SSH client is not connected.")

        target_name = (remote_name or os.path.basename(source)).strip()
        if not target_name:
            raise ValueError("remote_name resolves to empty filename.")
        remote_path = f"{self.workdir.rstrip('/')}/{target_name}"

        sftp = self.ssh_client.open_sftp()
        try:
            sftp.put(source, remote_path)
        finally:
            sftp.close()
        return remote_path

    def download(self, remote_path: str, local_path: str) -> str:
        """Download a remote file to a local path and return that local path."""
        target = os.path.abspath(local_path)
        parent = os.path.dirname(target)
        if parent:
            os.makedirs(parent, exist_ok=True)

        self.connect()
        if self.ssh_client is None:
            raise RuntimeError("SSH client is not connected.")

        sftp = self.ssh_client.open_sftp()
        try:
            sftp.get(remote_path, target)
        finally:
            sftp.close()
        return target

    def remove_remote_file(self, remote_path: str) -> None:
        """Best-effort removal of a remote file."""
        if not remote_path:
            return
        try:
            self.execute(
                f"rm -f {shlex.quote(remote_path)} >/dev/null 2>&1 || true"
            )
        except Exception:
            pass

    def execute(self, command: str, **kwargs: Any) -> dict[str, Any]:
        """Execute remote shell command over SSH."""
        self.connect()
        if self.ssh_client is None:
            raise RuntimeError("SSH client is not connected.")

        timeout = kwargs.get("timeout", self.timeout)
        get_pty = bool(kwargs.get("get_pty", False))
        check_exit = bool(kwargs.get("check_exit", False))

        stdin, stdout, stderr = self.ssh_client.exec_command(
            command=command,
            timeout=timeout,
            get_pty=get_pty,
        )
        if stdin:
            stdin.close()

        out_text = stdout.read().decode("utf-8", errors="replace")
        err_text = stderr.read().decode("utf-8", errors="replace")
        exit_status = int(stdout.channel.recv_exit_status())

        self.last_command = command
        self.last_error = None if exit_status == 0 else (err_text.strip() or f"exit={exit_status}")

        if check_exit and exit_status != 0:
            raise RuntimeError(
                f"Remote command failed (exit={exit_status}): {err_text.strip()}"
            )

        return {
            "exit_status": exit_status,
            "stdout": out_text,
            "stderr": err_text,
            "command": command,
        }

    def list_listener_pids(self, port: int) -> list[str]:
        """List remote listening process IDs for a TCP port."""
        command = (
            "if command -v lsof >/dev/null 2>&1; then "
            f"lsof -t -iTCP:{int(port)} -sTCP:LISTEN | sort -u; "
            "elif command -v ss >/dev/null 2>&1; then "
            f"ss -ltnp 'sport = :{int(port)}' | sed -n 's/.*pid=\\([0-9]\\+\\).*/\\1/p' | sort -u; "
            "elif command -v netstat >/dev/null 2>&1; then "
            f"netstat -lntp 2>/dev/null | awk '$4 ~ /:{int(port)}$/ {{print $7}}' | cut -d/ -f1 | sed '/^-/d' | sort -u; "
            "elif command -v fuser >/dev/null 2>&1; then "
            f"fuser -n tcp {int(port)} 2>/dev/null | tr ' ' '\\n' | sed '/^$/d' | sort -u; "
            "fi"
        )
        result = self.execute(command)
        stdout = str(result.get("stdout", "")).strip() if isinstance(result, dict) else ""
        pids: list[str] = []
        for raw_line in stdout.splitlines():
            token = raw_line.strip()
            token = re.sub(r"[^0-9]", "", token)
            if token.isdigit():
                pids.append(token)
        return sorted(set(pids))

    def ensure_port_available(
        self,
        port: int,
        *,
        wait_after_term: float = 1.0,
        wait_after_kill: float = 0.5,
    ) -> dict[str, Any]:
        """Ensure remote TCP port is not occupied by old listeners."""
        target_port = int(port)
        before = self.list_listener_pids(target_port)
        if not before:
            return {
                "port": target_port,
                "occupied_before": False,
                "killed_pids": [],
                "remaining_pids": [],
            }

        for pid in before:
            self.execute(f"kill -TERM {shlex.quote(pid)} >/dev/null 2>&1 || true")
        time.sleep(max(0.0, float(wait_after_term)))

        pending = self.list_listener_pids(target_port)
        for pid in pending:
            self.execute(f"kill -KILL {shlex.quote(pid)} >/dev/null 2>&1 || true")
        time.sleep(max(0.0, float(wait_after_kill)))

        remaining = self.list_listener_pids(target_port)
        if remaining:
            raise RuntimeError(f"Remote UI port {target_port} is still occupied by pids: {remaining}")
        return {
            "port": target_port,
            "occupied_before": True,
            "killed_pids": before,
            "remaining_pids": remaining,
        }

    def start(self, *args: Any, **kwargs: Any) -> None:
        """Start remote interactive process and open localhost forwarding tunnel."""
        if self.is_running():
            return

        self.connect()
        self.ensure_workdir()

        parsed = self._parse_start_kwargs(**kwargs)
        target_workdir = parsed["workdir"]
        remote_port = int(kwargs.get("port", kwargs.get("remote_port", self.remote_ui_port)))
        remote_ui_host = str(kwargs.get("remote_ui_host", self.remote_ui_host))
        local_host = str(kwargs.get("local_host", kwargs.get("local_forward_host", self.local_forward_host)))
        local_port = int(kwargs.get("local_port", kwargs.get("local_forward_port", self.local_forward_port)))
        startup_timeout = parsed["timeout"]
        wait_for_remote_port = bool(kwargs.get("wait_for_remote_port", True))
        wait_for_local_tunnel = bool(kwargs.get("wait_for_local_tunnel", True))
        extra_args = parsed["extra_args"]
        remote_log_file = str(kwargs.get("remote_log_file", self.remote_log_file))

        command = self.build_interactive_command(
            workdir=target_workdir,
            port=remote_port,
            extra_args=extra_args,
        )
        remote_command = " ".join(shlex.quote(part) for part in command)
        print("[RemoteTamarinProc.start] remote_command =", remote_command)

        detached_command = (
            f"nohup sh -lc {shlex.quote(remote_command)} "
            f"> {shlex.quote(remote_log_file)} 2>&1 & echo $!"
        )

        result = self.execute(detached_command, check_exit=True)
        pid_output = (result.get("stdout") or "").strip()
        parsed_pid = pid_output.splitlines()[-1].strip() if pid_output else ""
        if not parsed_pid:
            raise RuntimeError("Remote interactive process started but PID could not be parsed.")

        self.workdir = target_workdir
        self.remote_ui_host = remote_ui_host
        self.remote_ui_port = remote_port
        self.local_forward_host = local_host
        self.local_forward_port = local_port
        self.remote_log_file = remote_log_file

        self.remote_pid = parsed_pid
        self.pid = parsed_pid
        self.running = True

        if wait_for_remote_port and not self._wait_for_remote_service(remote_ui_host, remote_port, startup_timeout):
            self.stop()
            raise RuntimeError(
                f"Remote UI port did not become reachable: {remote_ui_host}:{remote_port}"
            )

        self._open_tunnel(
            local_host=local_host,
            local_port=local_port,
            remote_host=remote_ui_host,
            remote_port=remote_port,
        )

        if wait_for_local_tunnel and not _wait_for_tcp_port(
            self.local_forward_host,
            self.local_forward_port,
            startup_timeout,
        ):
            self.stop()
            raise RuntimeError(
                "Local forwarded endpoint is not reachable: "
                f"{self.local_forward_host}:{self.local_forward_port}"
            )

    def stop(self) -> None:
        """Stop remote interactive process and close SSH/tunnel resources."""
        if self.remote_pid:
            try:
                self.execute(f"kill {shlex.quote(self.remote_pid)} >/dev/null 2>&1 || true")
            except Exception:
                pass

        self.remote_pid = None
        self.pid = None
        self.running = False
        self.disconnect()

    def _probe_alive(self) -> bool:
        """Return True when tracked remote process is still alive."""
        if not self.remote_pid:
            return False
        if self.ssh_client is None:
            return False
        return self._is_remote_pid_alive(self.remote_pid)

    def is_running(self) -> bool:
        """Probe liveness, sync state, clear remote-specific handles on death."""
        alive = super().is_running()
        if not alive:
            self.remote_pid = None
        return alive

    def _is_remote_pid_alive(self, pid: str) -> bool:
        if self.ssh_client is None:
            return False
        try:
            stdin, stdout, stderr = self.ssh_client.exec_command(
                f"kill -0 {shlex.quote(pid)} >/dev/null 2>&1",
                timeout=self.timeout,
            )
            if stdin:
                stdin.close()
            stdout.read()
            stderr.read()
            return int(stdout.channel.recv_exit_status()) == 0
        except Exception:
            return False

    def _wait_for_remote_service(self, remote_host: str, remote_port: int, timeout: float) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.remote_pid and not self._is_remote_pid_alive(self.remote_pid):
                return False
            if self._probe_remote_service(remote_host, remote_port):
                return True
            time.sleep(0.25)
        return False

    def _probe_remote_service(self, remote_host: str, remote_port: int) -> bool:
        transport = self._require_transport()
        channel = None
        try:
            channel = transport.open_channel(
                kind="direct-tcpip",
                dest_addr=(remote_host, int(remote_port)),
                src_addr=("127.0.0.1", 0),
                timeout=self.timeout,
            )
            return channel is not None
        except Exception:
            return False
        finally:
            if channel is not None:
                channel.close()

    def _open_tunnel(
        self,
        *,
        local_host: str,
        local_port: int,
        remote_host: str,
        remote_port: int,
    ) -> None:
        self._close_tunnel()

        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((local_host, int(local_port)))
        listener.listen(128)
        listener.settimeout(0.5)

        stop_event = threading.Event()
        accept_thread = threading.Thread(
            target=self._tunnel_accept_loop,
            args=(listener, stop_event, remote_host, int(remote_port)),
            name="tamarin-ssh-tunnel",
            daemon=True,
        )
        accept_thread.start()

        assigned_host, assigned_port = listener.getsockname()
        self._tunnel_listener = listener
        self._tunnel_thread = accept_thread
        self._tunnel_stop_event = stop_event
        self.local_forward_host = str(assigned_host)
        self.local_forward_port = int(assigned_port)
        self.forwarded_base_url = f"http://{self.local_forward_host}:{self.local_forward_port}"

    def _close_tunnel(self) -> None:
        if self._tunnel_stop_event is not None:
            self._tunnel_stop_event.set()

        if self._tunnel_listener is not None:
            try:
                self._tunnel_listener.close()
            except OSError:
                pass
            self._tunnel_listener = None

        if self._tunnel_thread is not None:
            self._tunnel_thread.join(timeout=2.0)
            self._tunnel_thread = None

        with self._tunnel_lock:
            workers = list(self._tunnel_workers)
            self._tunnel_workers.clear()
        for worker in workers:
            worker.join(timeout=1.0)

        self._tunnel_stop_event = None
        self.forwarded_base_url = None

    def _tunnel_accept_loop(
        self,
        listener: socket.socket,
        stop_event: threading.Event,
        remote_host: str,
        remote_port: int,
    ) -> None:
        while not stop_event.is_set():
            try:
                client_socket, _ = listener.accept()
            except socket.timeout:
                self._cleanup_tunnel_workers()
                continue
            except OSError:
                break

            worker = threading.Thread(
                target=self._tunnel_client_loop,
                args=(client_socket, remote_host, remote_port),
                daemon=True,
            )
            with self._tunnel_lock:
                self._tunnel_workers.add(worker)
            worker.start()
            self._cleanup_tunnel_workers()

    def _cleanup_tunnel_workers(self) -> None:
        with self._tunnel_lock:
            dead_workers = [thread for thread in self._tunnel_workers if not thread.is_alive()]
            for thread in dead_workers:
                self._tunnel_workers.discard(thread)

    def _tunnel_client_loop(
        self,
        client_socket: socket.socket,
        remote_host: str,
        remote_port: int,
    ) -> None:
        channel = None
        try:
            transport = self._require_transport()
            src_addr = ("127.0.0.1", 0)
            try:
                src_addr = client_socket.getpeername()
            except OSError:
                pass
            channel = transport.open_channel(
                kind="direct-tcpip",
                dest_addr=(remote_host, int(remote_port)),
                src_addr=src_addr,
                timeout=self.timeout,
            )
            if channel is None:
                return

            while True:
                readable, _, _ = select.select([client_socket, channel], [], [], 1.0)
                if client_socket in readable:
                    payload = client_socket.recv(32_768)
                    if not payload:
                        break
                    channel.sendall(payload)
                if channel in readable:
                    payload = channel.recv(32_768)
                    if not payload:
                        break
                    client_socket.sendall(payload)
        except Exception:
            pass
        finally:
            try:
                client_socket.close()
            except OSError:
                pass
            if channel is not None:
                channel.close()
            current = threading.current_thread()
            with self._tunnel_lock:
                self._tunnel_workers.discard(current)

    def _require_transport(self) -> Any:
        if self.ssh_client is None:
            raise RuntimeError("SSH client is not connected.")
        transport = self.ssh_client.get_transport()
        if transport is None or not transport.is_active():
            raise RuntimeError("SSH transport is not active.")
        return transport
