"""Lemma step extraction and verification status inference."""

from __future__ import annotations

import json
import re
from typing import Any

from tamarin_infra.parsing import parser as tamarin_parser


def extract_lemma_steps(
    *,
    lemma_name: str,
    verification_result: Any,
) -> tuple[bool, list[dict[str, Any]]]:
    """Extract lemma-scoped ordered step entries from multiple result formats."""
    target = lemma_name.strip()
    if not target:
        return False, []

    if isinstance(verification_result, dict):
        # Preferred structure: prove_lemmas bundle.
        lemma_process = verification_result.get("lemma_process")
        if isinstance(lemma_process, dict):
            for key, value in lemma_process.items():
                if str(key or "").strip() != target:
                    continue
                if isinstance(value, list):
                    normalized = [item for item in value if isinstance(item, dict)]
                    return True, normalized
                return True, []

        # Single-lemma report shape.
        payload_lemma = str(verification_result.get("lemma") or "").strip()
        if payload_lemma == target:
            raw_steps = verification_result.get("step")
            if isinstance(raw_steps, list):
                normalized = [item for item in raw_steps if isinstance(item, dict)]
                return True, normalized
            return True, []

        # Flat step list (cross-lemma).
        steps = verification_result.get("steps")
        if isinstance(steps, list):
            filtered = [
                item for item in steps
                if isinstance(item, dict)
                and str(item.get("lemma") or "").strip() == target
            ]
            if filtered:
                return True, filtered

        return False, []

    if isinstance(verification_result, list):
        filtered = [
            item for item in verification_result
            if isinstance(item, dict)
            and str(item.get("lemma") or "").strip() == target
        ]
        return (len(filtered) > 0), filtered

    if isinstance(verification_result, str):
        return _extract_lemma_steps_from_text(
            lemma_name=target,
            raw_text=verification_result,
        )

    return False, []


def infer_lemma_status(
    *,
    lemma_name: str,
    verification_result: Any,
    lemma_steps: list[dict[str, Any]],
) -> str:
    """Infer lemma verification status from structured fields first."""
    target = lemma_name.strip()
    if not target:
        return "unknown"

    if isinstance(verification_result, dict):
        lemma_proof_states = verification_result.get("lemma_proof_states")
        if isinstance(lemma_proof_states, dict):
            state_payload = lemma_proof_states.get(target)
            if isinstance(state_payload, dict):
                status = _normalize_status_value(
                    state_payload.get("result") or state_payload.get("state")
                )
                if status != "unknown":
                    return status

        payload_lemma = str(verification_result.get("lemma") or "").strip()
        if payload_lemma == target:
            proof_state = verification_result.get("proof_state")
            if isinstance(proof_state, dict):
                status = _normalize_status_value(
                    proof_state.get("result") or proof_state.get("state")
                )
                if status != "unknown":
                    return status

    for step in reversed(lemma_steps):
        if not isinstance(step, dict):
            continue
        proof_state = step.get("proof_state")
        if not isinstance(proof_state, dict):
            continue
        status = _normalize_status_value(
            proof_state.get("result") or proof_state.get("state")
        )
        if status != "unknown":
            return status

    if isinstance(verification_result, str):
        return _infer_status_from_text(verification_result)

    try:
        fallback_text = json.dumps(verification_result, ensure_ascii=False, default=str)
    except Exception:
        fallback_text = str(verification_result)
    return _infer_status_from_text(fallback_text)


def choose_target_lemmas(*, lemmas: list[str], target_lemma: str | None) -> list[str]:
    if target_lemma:
        for lemma in lemmas:
            if lemma.strip() == target_lemma.strip():
                return [lemma]
        raise RuntimeError(f"Configured target lemma was not found: {target_lemma}")
    return list(lemmas)


def format_selected_goal(
    *,
    selected_candidate: str,
    grouped_goals: dict[str, list[str]] | None,
) -> str:
    candidate = (selected_candidate or "").strip()
    if not candidate:
        return ""
    if not isinstance(grouped_goals, dict):
        return f"default:{candidate}"

    for case_name, goals in grouped_goals.items():
        if not isinstance(case_name, str) or not isinstance(goals, list):
            continue
        for goal in goals:
            if not isinstance(goal, str):
                continue
            if strip_case_prefix(goal) == candidate:
                return f"{case_name}:{candidate}"

    default_case = "default"
    if grouped_goals:
        first_case = next(iter(grouped_goals.keys()), "")
        if isinstance(first_case, str) and first_case.strip():
            default_case = first_case.strip()
    return f"{default_case}:{candidate}"


def strip_case_prefix(value: str) -> str:
    text = (value or "").strip()
    if not text:
        return ""
    if ":" not in text:
        return text
    _prefix, _sep, tail = text.partition(":")
    return tail.strip() or text


def extract_lemma_for_state(state: dict[str, Any], current_url: str | None) -> str:
    lemma = state.get("lemma") if isinstance(state, dict) else ""
    if isinstance(lemma, str) and lemma.strip():
        return lemma.strip()
    fallback = tamarin_parser.extract_lemma_from_proof_url(current_url)
    return fallback or ""


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------


def _extract_lemma_steps_from_text(
    *,
    lemma_name: str,
    raw_text: str,
) -> tuple[bool, list[dict[str, Any]]]:
    """Best-effort parser for raw textual verification output."""
    content = _extract_lemma_text_block(
        lemma_name=lemma_name,
        raw_text=raw_text,
    )
    if not content:
        return False, []

    steps: list[dict[str, Any]] = []
    current_case = "default"

    for line in content.splitlines():
        stripped = line.strip()
        if not stripped:
            continue

        case_match = re.match(r"(?i)^case\s+([^\s:]+)", stripped)
        if case_match:
            current_case = case_match.group(1).strip() or "default"
            continue

        if stripped.lower() in {"next", "qed"}:
            continue

        by_match = re.match(r"(?i)^by\s+(.+)$", stripped)
        if by_match:
            rule_text = re.sub(r"/\*.*?\*/", "", by_match.group(1)).strip()
            if rule_text:
                steps.append({"selected_goal": f"{current_case}:{rule_text}"})
            continue

        solve_match = re.match(r"(?i)^solve\s*\((.+)\)\s*$", stripped)
        if solve_match:
            rule_text = f"solve({solve_match.group(1).strip()})"
            steps.append({"selected_goal": f"{current_case}:{rule_text}"})
            continue

        method_match = re.match(r"(?i)^(simplify|induction|autoprove(?:\s*\(.*\))?)\b.*$", stripped)
        if method_match:
            rule_text = method_match.group(0).strip()
            steps.append({"selected_goal": f"{current_case}:{rule_text}"})

    return True, steps


def _extract_lemma_text_block(
    *,
    lemma_name: str,
    raw_text: str,
) -> str:
    """Extract one lemma block from raw verification text conservatively."""
    text = raw_text or ""
    if not text.strip():
        return ""

    lemma_decl_pattern = re.compile(
        r"(?im)^\s*(?:all-traces|exists-trace)?\s*lemma\s+([^\s:\[]+)\s*:?.*$"
    )
    matches = list(lemma_decl_pattern.finditer(text))
    if not matches:
        return ""

    target_exact = lemma_name.strip()
    target_lower = target_exact.lower()
    target_match: re.Match[str] | None = None

    for match in matches:
        current = (match.group(1) or "").strip()
        if current == target_exact:
            target_match = match
            break

    if target_match is None:
        for match in matches:
            current = (match.group(1) or "").strip().lower()
            if current == target_lower:
                target_match = match
                break

    if target_match is None:
        return ""

    start = target_match.start()
    end = len(text)
    for match in matches:
        if match.start() > start:
            end = match.start()
            break
    return text[start:end]


def _normalize_status_value(value: Any) -> str:
    """Normalize status value to `verified` / `falsified` / `unknown`."""
    text = str(value or "").strip().lower()
    if not text:
        return "unknown"

    verified_markers = ("verified", "proved", "proven", "success")
    falsified_markers = ("falsified", "counterexample", "failed", "attack", "unverified")

    if any(marker in text for marker in verified_markers):
        return "verified"
    if any(marker in text for marker in falsified_markers):
        return "falsified"
    return "unknown"


def _infer_status_from_text(text: str) -> str:
    """Infer status from raw text when no structured status exists."""
    normalized = (text or "").lower()
    if not normalized.strip():
        return "unknown"
    if any(marker in normalized for marker in ("verified", "proved", "proven", "qed")):
        return "verified"
    if any(marker in normalized for marker in ("falsified", "counterexample", "attack found", "failed")):
        return "falsified"
    return "unknown"
