"""Proof-graph analysis: load and extract protocol rule order for action blocks."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


def _dedupe_preserve_order(values: list[str]) -> list[str]:
    result: list[str] = []
    seen: set[str] = set()
    for item in values:
        normalized = item.strip()
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        result.append(normalized)
    return result


def parse_lemma_case_order(
    lemma_name: str,
    path: Any,
) -> list[str]:
    """Return protocol rule labels ordered by Test action facts."""
    target_lemma = (lemma_name or "").strip()
    if not target_lemma:
        raise ValueError("lemma_name cannot be empty.")

    payload = _load_proof_graph_payload(path)
    graph = _select_relevant_graph(payload=payload, lemma_name=target_lemma)
    node_map, node_labels, protocol_node_ids = _collect_graph_nodes(graph=graph)
    return _extract_test_action_protocol_order(
        protocol_node_ids=protocol_node_ids,
        node_map=node_map,
        node_labels=node_labels,
    )


def _is_test_action_fact_name(name: str) -> bool:
    return (name or "").strip().lower().startswith("test")


def _extract_test_action_protocol_order(
    *,
    protocol_node_ids: list[str],
    node_map: dict[str, dict[str, Any]],
    node_labels: dict[str, str],
) -> list[str]:
    ordered_labels: list[str] = []

    for node_id in protocol_node_ids:
        node = node_map.get(node_id, {})
        action_facts = _collect_fact_entries(node, "jgnActs")
        has_test_action = any(
            _is_test_action_fact_name(str(entry.get("jgnFactName") or ""))
            for entry in action_facts
        )
        if not has_test_action:
            continue

        label = str(node_labels.get(node_id) or "").strip()
        if label:
            ordered_labels.append(label)

    deduped_labels = _dedupe_preserve_order(ordered_labels)
    if not deduped_labels:
        raise ValueError("Failed to derive a non-empty protocol flow from Test action facts.")
    return deduped_labels


def _load_proof_graph_payload(source: Any) -> dict[str, Any]:
    if isinstance(source, dict):
        return source

    if isinstance(source, Path):
        return _read_json_object_file(source.expanduser())

    if isinstance(source, str):
        raw = source.strip()
        if not raw:
            raise ValueError("path cannot be empty.")

        path_obj = Path(raw).expanduser()
        if path_obj.exists():
            return _read_json_object_file(path_obj)

        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise FileNotFoundError(f"Verification result JSON file not found: {path_obj}") from exc
        if not isinstance(payload, dict):
            raise ValueError("Proof graph JSON payload must be an object with a 'graphs' field.")
        return payload

    raise TypeError("path must be a file path (str/Path) or a proof-graph JSON object (dict).")


def _read_json_object_file(path_obj: Path) -> dict[str, Any]:
    if not path_obj.exists() or not path_obj.is_file():
        raise FileNotFoundError(f"Verification result file not found: {path_obj}")
    try:
        raw_text = path_obj.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raw_text = path_obj.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        raise RuntimeError(f"Failed to read verification result file: {path_obj}") from exc

    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Verification result file is not valid JSON: {path_obj}") from exc
    if not isinstance(payload, dict):
        raise ValueError(
            f"Verification result JSON must be an object with a 'graphs' field: {path_obj}"
        )
    return payload


def _select_relevant_graph(
    *,
    payload: dict[str, Any],
    lemma_name: str,
) -> dict[str, Any]:
    raw_graphs = payload.get("graphs")
    if not isinstance(raw_graphs, list) or not raw_graphs:
        raise ValueError("Invalid proof graph JSON: missing non-empty 'graphs' list.")

    graphs: list[tuple[int, dict[str, Any]]] = [
        (index, item)
        for index, item in enumerate(raw_graphs)
        if isinstance(item, dict)
    ]
    if not graphs:
        raise ValueError("Invalid proof graph JSON: no valid graph objects found in 'graphs'.")
    if len(graphs) == 1:
        return graphs[0][1]

    target = lemma_name.strip().lower()
    exact_matches: list[tuple[int, dict[str, Any]]] = []
    fuzzy_matches: list[tuple[int, dict[str, Any]]] = []

    for index, graph in graphs:
        graph_lemma = str(graph.get("jgLemma") or "").strip()
        graph_label = str(graph.get("jgLabel") or "").strip()

        if graph_lemma and graph_lemma.lower() == target:
            exact_matches.append((index, graph))
            continue

        if target and (
            target in graph_lemma.lower()
            or target in graph_label.lower()
        ):
            fuzzy_matches.append((index, graph))

    if exact_matches:
        return exact_matches[0][1]
    if fuzzy_matches:
        return fuzzy_matches[0][1]

    available = [
        str(graph.get("jgLemma") or graph.get("jgLabel") or f"graphs[{index}]")
        for index, graph in graphs
    ]
    raise ValueError(
        f"No graph matches lemma '{lemma_name}'. Available graph labels: {available}"
    )


def _collect_graph_nodes(
    *,
    graph: dict[str, Any],
) -> tuple[dict[str, dict[str, Any]], dict[str, str], list[str]]:
    top_level_nodes = graph.get("jgNodes")
    if top_level_nodes is None:
        top_level_nodes = []
    if not isinstance(top_level_nodes, list):
        raise ValueError("Invalid proof graph: 'jgNodes' must be a list when present.")

    cluster_nodes: list[dict[str, Any]] = []
    raw_clusters = graph.get("jgClusters")
    if raw_clusters is None:
        raw_clusters = []
    if not isinstance(raw_clusters, list):
        raise ValueError("Invalid proof graph: 'jgClusters' must be a list when present.")
    for cluster_index, cluster in enumerate(raw_clusters):
        if not isinstance(cluster, dict):
            raise ValueError(f"Invalid proof graph: cluster at jgClusters[{cluster_index}] must be an object.")
        raw_cluster_nodes = cluster.get("jgcNodes")
        if raw_cluster_nodes is None:
            continue
        if not isinstance(raw_cluster_nodes, list):
            raise ValueError(
                f"Invalid proof graph: jgcNodes at jgClusters[{cluster_index}] must be a list."
            )
        for node in raw_cluster_nodes:
            if isinstance(node, dict):
                cluster_nodes.append(node)

    all_nodes: list[dict[str, Any]] = []
    for node in top_level_nodes:
        if isinstance(node, dict):
            all_nodes.append(node)
    all_nodes.extend(cluster_nodes)

    if not all_nodes:
        raise ValueError("Invalid proof graph: no nodes found in 'jgNodes' or 'jgClusters[*].jgcNodes'.")

    node_map: dict[str, dict[str, Any]] = {}
    node_labels: dict[str, str] = {}
    node_types: dict[str, str] = {}
    protocol_node_ids: list[str] = []

    for index, node in enumerate(all_nodes):
        if not isinstance(node, dict):
            raise ValueError(f"Invalid proof graph: node at jgNodes[{index}] must be an object.")

        node_id = str(node.get("jgnId") or "").strip()
        if not node_id:
            raise ValueError(f"Invalid proof graph: node at jgNodes[{index}] is missing 'jgnId'.")
        node_type = str(node.get("jgnType") or "").strip()
        node_label = str(node.get("jgnLabel") or "").strip()

        if node_id in node_map:
            existing_label = node_labels[node_id]
            existing_type = node_types[node_id]
            if existing_label == node_label and existing_type == node_type:
                continue
            raise ValueError(f"Invalid proof graph: duplicate node id '{node_id}' with conflicting metadata.")

        node_map[node_id] = node
        node_labels[node_id] = node_label
        node_types[node_id] = node_type

        if node_type == "isProtocolRule":
            if not node_label:
                raise ValueError(f"Protocol node '{node_id}' is missing 'jgnLabel'.")
            protocol_node_ids.append(node_id)

    if not protocol_node_ids:
        raise ValueError("Proof graph contains no protocol rule nodes (jgnType == 'isProtocolRule').")

    return node_map, node_labels, protocol_node_ids


def _collect_fact_entries(node: dict[str, Any], field: str) -> list[dict[str, Any]]:
    metadata = node.get("jgnMetadata")
    if not isinstance(metadata, dict):
        return []
    raw_items = metadata.get(field)
    if not isinstance(raw_items, list):
        return []
    return [item for item in raw_items if isinstance(item, dict)]
