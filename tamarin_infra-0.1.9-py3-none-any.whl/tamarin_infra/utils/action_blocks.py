﻿from __future__ import annotations

import re
from pathlib import Path

import yaml

_RULE_HEADER_RE = re.compile(
    r'^\s*rule\b(?:\s+\([^)]*\))*\s+(?P<name>"[^"]+"|[^\s\[:]+)\s*(?:\[[^\]]*\])?\s*:\s*$',
    re.MULTILINE,
)
_TOP_LEVEL_BOUNDARY_RE = re.compile(
    r'^\s*(?:rule\b(?:\s+\([^)]*\))*\s+(?:"[^"]+"|[^\s\[:]+)\s*(?:\[[^\]]*\])?\s*:|lemma\b|restriction\b|tactic\b|end\b)',
    re.MULTILINE,
)
_TRANSITION_WITH_ACTION_RE = re.compile(
    r"\[(?P<lhs>.*?)\]\s*(?://[^\n]*\n\s*)*--\s*\[(?P<act>.*?)\]\s*->\s*\[(?P<rhs>.*?)\]",
    re.DOTALL,
)
_TRANSITION_NO_ACTION_RE = re.compile(r"\[(?P<lhs>.*?)\]\s*-->\s*\[(?P<rhs>.*?)\]", re.DOTALL)
_LET_BLOCK_RE = re.compile(r"\blet\b(?P<body>.*?)\bin\b", re.DOTALL)
_NAME_RE = re.compile(r"^[A-Za-z_]\w*$")


def _strip_inline_comment(value: str) -> str:
    return re.sub(r"\s*//.*$", "", value)


def _clean_text(value: str) -> str:
    return " ".join(_strip_inline_comment(value).strip().split())


_SUGAR_BRACE_RE = re.compile(
    r"([A-Za-z_]\w*)\s*\{([^{}]*)\}\s*([~$]?[A-Za-z_]\w*(?:\.\w+)*)"
)


def _normalize_expression(value: str) -> str:
    if not value:
        return value
    text = value
    while True:
        rewritten = _SUGAR_BRACE_RE.sub(
            lambda m: f"{m.group(1)}(<{m.group(2).strip()}>, {m.group(3)})",
            text,
        )
        if rewritten == text:
            break
        text = rewritten
    text = re.sub(r"\s*\^\s*", "^", text)
    text = re.sub(r"\s*\|\s*", "|", text)
    text = re.sub(r"\s*,\s*", ", ", text)
    text = re.sub(r"<\s+", "<", text)
    text = re.sub(r"\s+>", ">", text)
    text = re.sub(r"\(\s+", "(", text)
    text = re.sub(r"\s+\)", ")", text)
    return _clean_text(text)


def _normalize_case_name(case_name: str) -> str:
    trimmed = case_name.strip()
    if "_case_" in trimmed:
        return trimmed.split("_case_", 1)[0]
    return trimmed


def _dedupe_keep_order(items: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        value = _normalize_expression(_clean_text(item))
        if not value or value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def _normalize_keep_order(items: list[str]) -> list[str]:
    result: list[str] = []
    for item in items:
        value = _normalize_expression(_clean_text(item))
        if value:
            result.append(value)
    return result


def _remove_line_comments(text: str) -> str:
    return "\n".join(
        re.sub(r"//.*", "", line)
        for line in text.splitlines()
    )


def _split_top_level(text: str) -> list[str]:
    text = _remove_line_comments(text)
    if not text.strip():
        return []

    result: list[str] = []
    current: list[str] = []
    depth_paren = depth_bracket = depth_brace = depth_angle = 0
    in_single_quote = False

    for ch in text:
        if ch == "'":
            in_single_quote = not in_single_quote
            current.append(ch)
            continue

        if not in_single_quote:
            if ch == "(":
                depth_paren += 1
            elif ch == ")":
                depth_paren = max(0, depth_paren - 1)
            elif ch == "[":
                depth_bracket += 1
            elif ch == "]":
                depth_bracket = max(0, depth_bracket - 1)
            elif ch == "{":
                depth_brace += 1
            elif ch == "}":
                depth_brace = max(0, depth_brace - 1)
            elif ch == "<":
                depth_angle += 1
            elif ch == ">":
                depth_angle = max(0, depth_angle - 1)

            if (
                ch == ","
                and depth_paren == 0
                and depth_bracket == 0
                and depth_brace == 0
                and depth_angle == 0
            ):
                part = _clean_text("".join(current))
                if part:
                    result.append(part)
                current = []
                continue

        current.append(ch)

    tail = _clean_text("".join(current))
    if tail:
        result.append(tail)
    return result


def _parse_call(expr: str) -> tuple[str, list[str]] | None:
    text = _clean_text(expr)
    open_idx = text.find("(")
    if open_idx <= 0:
        return None

    pred = text[:open_idx].strip()
    if not re.match(r"^[A-Za-z_]\w*$", pred):
        return None

    depth = 0
    close_idx = -1
    in_single_quote = False
    for idx in range(open_idx, len(text)):
        ch = text[idx]
        if ch == "'":
            in_single_quote = not in_single_quote
            continue
        if in_single_quote:
            continue
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth == 0:
                close_idx = idx
                break

    if close_idx == -1:
        return None

    suffix = text[close_idx + 1 :].strip()
    if suffix:
        return None

    args = _split_top_level(text[open_idx + 1 : close_idx])
    return pred, args


def _payload_items_from_fact(fact: str) -> list[str]:
    parsed = _parse_call(fact)
    if not parsed:
        return []

    pred, args = parsed
    payload = ""
    if pred in {"SIn", "SOut"} and len(args) >= 5:
        payload = args[4]
    elif pred in {"In", "Out"} and args:
        payload = args[0]
    else:
        return []

    payload = _clean_text(payload)
    if payload.startswith("<") and payload.endswith(">"):
        return _split_top_level(payload[1:-1])
    return [payload] if payload else []


def _extract_rule_body(rule_text: str) -> tuple[list[str], list[str], list[str]]:
    header = _RULE_HEADER_RE.match(rule_text)
    body = rule_text[header.end() :] if header else rule_text

    with_action = _TRANSITION_WITH_ACTION_RE.search(body)
    if with_action:
        lhs = _split_top_level(with_action.group("lhs"))
        act = _split_top_level(with_action.group("act"))
        rhs = _split_top_level(with_action.group("rhs"))
        return lhs, act, rhs

    no_action = _TRANSITION_NO_ACTION_RE.search(body)
    if no_action:
        lhs = _split_top_level(no_action.group("lhs"))
        rhs = _split_top_level(no_action.group("rhs"))
        return lhs, [], rhs

    return [], [], []


def _parse_model_rules(model_file: Path) -> dict[str, dict[str, object]]:
    content = model_file.read_text(encoding="utf-8")
    rule_headers = list(_RULE_HEADER_RE.finditer(content))

    parsed: dict[str, dict[str, object]] = {}
    for header in rule_headers:
        start = header.start()
        next_boundary = _TOP_LEVEL_BOUNDARY_RE.search(content, pos=header.end())
        end = next_boundary.start() if next_boundary else len(content)

        raw_rule_text = content[start:end].strip()
        name = header.group("name").strip()
        if name.startswith('"') and name.endswith('"') and len(name) >= 2:
            name = name[1:-1]

        lhs, action, rhs = _extract_rule_body(raw_rule_text)
        parsed[name] = {
            "rule_name": name,
            "raw_rule_text": raw_rule_text,
            "lhs": lhs,
            "action": action,
            "rhs": rhs,
        }

    return parsed


def _find_top_level_equals(text: str) -> int:
    depth_paren = depth_bracket = depth_brace = depth_angle = 0
    in_single_quote = False

    for idx, ch in enumerate(text):
        if ch == "'":
            in_single_quote = not in_single_quote
            continue
        if in_single_quote:
            continue

        if ch == "(":
            depth_paren += 1
            continue
        if ch == ")":
            depth_paren = max(0, depth_paren - 1)
            continue
        if ch == "[":
            depth_bracket += 1
            continue
        if ch == "]":
            depth_bracket = max(0, depth_bracket - 1)
            continue
        if ch == "{":
            depth_brace += 1
            continue
        if ch == "}":
            depth_brace = max(0, depth_brace - 1)
            continue
        if ch == "<":
            depth_angle += 1
            continue
        if ch == ">":
            depth_angle = max(0, depth_angle - 1)
            continue

        if ch != "=" or depth_paren or depth_bracket or depth_brace or depth_angle:
            continue

        prev_ch = text[idx - 1] if idx > 0 else ""
        next_ch = text[idx + 1] if idx + 1 < len(text) else ""
        if prev_ch in {"!", "<", ">", "="} or next_ch == "=":
            continue
        return idx

    return -1


def _is_balanced_expression(text: str) -> bool:
    depth_paren = depth_bracket = depth_brace = depth_angle = 0
    in_single_quote = False

    for ch in text:
        if ch == "'":
            in_single_quote = not in_single_quote
            continue
        if in_single_quote:
            continue
        if ch == "(":
            depth_paren += 1
        elif ch == ")":
            depth_paren -= 1
        elif ch == "[":
            depth_bracket += 1
        elif ch == "]":
            depth_bracket -= 1
        elif ch == "{":
            depth_brace += 1
        elif ch == "}":
            depth_brace -= 1
        elif ch == "<":
            depth_angle += 1
        elif ch == ">":
            depth_angle -= 1

    return (
        depth_paren == 0
        and depth_bracket == 0
        and depth_brace == 0
        and depth_angle == 0
        and not in_single_quote
    )


def _parse_let_assignment(assignment: str) -> tuple[str, str] | None:
    eq_idx = _find_top_level_equals(assignment)
    if eq_idx < 0:
        return None

    lhs = _clean_text(assignment[:eq_idx])
    rhs = _clean_text(assignment[eq_idx + 1 :].rstrip(","))
    if not lhs or not rhs:
        return None
    if not _NAME_RE.match(lhs):
        return None
    return lhs, rhs


def _extract_let_assignments(raw_rule_text: str) -> list[tuple[str, str]]:
    match = _LET_BLOCK_RE.search(raw_rule_text)
    if not match:
        return []

    body = match.group("body")
    lines = body.splitlines()

    assignments: list[tuple[str, str]] = []
    current: str | None = None

    for raw_line in lines:
        line = _clean_text(raw_line)
        if not line:
            continue
        if line.startswith("let "):
            line = _clean_text(line[4:])
            if not line:
                continue

        if _find_top_level_equals(line) >= 0:
            if current:
                parsed = _parse_let_assignment(current)
                if parsed:
                    assignments.append(parsed)
            current = line
        elif current:
            current = f"{current} {line}"
        else:
            continue

        if current and _is_balanced_expression(current):
            parsed = _parse_let_assignment(current)
            if parsed:
                assignments.append(parsed)
            current = None

    if current:
        parsed = _parse_let_assignment(current)
        if parsed:
            assignments.append(parsed)

    return assignments


def _expand_with_bindings(text: str, bindings: dict[str, str]) -> str:
    expanded = _clean_text(text)
    if not expanded or not bindings:
        return expanded

    for name in sorted(bindings.keys(), key=len, reverse=True):
        replacement = _clean_text(bindings[name])
        if not replacement:
            continue
        pattern = rf"(?<![A-Za-z0-9_$~']){re.escape(name)}(?![A-Za-z0-9_])"
        expanded = re.sub(pattern, replacement, expanded)

    return _clean_text(expanded)


def _normalize_case_order(case_order: list[str]) -> list[tuple[str, str]]:
    if not isinstance(case_order, list):
        raise TypeError("case_order must be a list of strings")

    normalized: list[tuple[str, str]] = []
    for idx, item in enumerate(case_order):
        if not isinstance(item, str):
            raise ValueError(f"case_order[{idx}] must be a string")
        case = item.strip()
        normalized.append((case, _normalize_case_name(case)))
    return normalized


def _extract_role(case_name: str) -> str:
    return case_name.strip()


def _extract_receive(lhs_facts: list[str]) -> list[str]:
    receive: list[str] = []
    for fact in lhs_facts:
        parsed = _parse_call(fact)
        if not parsed:
            continue
        pred, _ = parsed
        if pred in {"In", "SIn"}:
            receive.extend(_payload_items_from_fact(fact))
    return _normalize_keep_order(receive)


def _extract_generate_nonces(lhs_facts: list[str]) -> list[str]:
    nonces: list[str] = []
    for fact in lhs_facts:
        parsed = _parse_call(fact)
        if not parsed:
            continue
        pred, args = parsed
        if pred == "Fr" and args:
            nonces.append(args[0])
    return _dedupe_keep_order(nonces)


def _extract_compute(raw_rule_text: str) -> list[str]:
    assignments = _extract_let_assignments(raw_rule_text)
    bindings: dict[str, str] = {}

    compute: list[str] = []
    for name, rhs in assignments:
        expanded_rhs = _expand_with_bindings(rhs, bindings)
        bindings[name] = expanded_rhs
        compute.append(f"{name} = {expanded_rhs}")

    return _dedupe_keep_order(compute)


def _extract_assert(action_facts: list[str]) -> list[str]:
    asserts: list[str] = []
    for fact in action_facts:
        parsed = _parse_call(fact)
        if not parsed:
            continue
        pred, args = parsed
        if pred != "Eq" or len(args) < 2:
            continue
        lhs = _clean_text(args[0])
        rhs = _clean_text(args[1])
        if lhs and rhs:
            asserts.append(f"{lhs} = {rhs}")
    return _dedupe_keep_order(asserts)


def _extract_send(rhs_facts: list[str]) -> list[str]:
    send: list[str] = []
    for fact in rhs_facts:
        parsed = _parse_call(fact)
        if not parsed:
            continue
        pred, _ = parsed
        if pred in {"Out", "SOut"}:
            send.extend(_payload_items_from_fact(fact))
    return _normalize_keep_order(send)


def _build_action_blocks(
    ordered_cases: list[tuple[str, str]],
    parsed_rule_map: dict[str, dict[str, object]],
) -> list[dict[str, object]]:
    action_blocks: list[dict[str, object]] = []

    for index, (original_case, normalized_case) in enumerate(ordered_cases):
        rule = parsed_rule_map.get(normalized_case)
        if rule is None:
            raise ValueError(
                f"Rule not found for case '{original_case}' (normalized as '{normalized_case}')"
            )

        lhs = list(rule.get("lhs", []))
        rhs = list(rule.get("rhs", []))
        action = list(rule.get("action", []))
        raw_rule_text = str(rule.get("raw_rule_text", ""))

        receive_items = _extract_receive(lhs)
        nonce_items = _extract_generate_nonces(lhs)
        compute_items = _extract_compute(raw_rule_text)
        assert_items = _extract_assert(action)

        operations: list[dict[str, object]] = []
        if receive_items:
            operations.append({"receive": receive_items})
        if nonce_items:
            operations.append({"generate_nonces": nonce_items})
        if compute_items:
            operations.append({"compute": compute_items})
        if assert_items:
            operations.append({"assert": assert_items})

        is_final_step = index == len(ordered_cases) - 1
        if is_final_step:
            operations.append({"send": "<END>"})
        else:
            operations.append({"send": _extract_send(rhs)})

        action_blocks.append(
            {
                "role": _extract_role(original_case),
                "operations": operations,
            }
        )

    return action_blocks


def generate_action_blocks(
    case_order: list[str],
    model_file: str | Path,
) -> list[dict[str, object]]:
    """Generate action blocks from a case-order list and a .spthy model file."""
    ordered_cases = _normalize_case_order(case_order)
    parsed_rule_map = _parse_model_rules(Path(model_file).expanduser())
    return _build_action_blocks(ordered_cases, parsed_rule_map)


def dump_action_blocks_yaml(action_blocks: list[dict[str, object]]) -> str:
    """Serialize action blocks to YAML text."""
    yaml_text = yaml.safe_dump(
        action_blocks,
        allow_unicode=True,
        sort_keys=False,
        default_flow_style=False,
    )
    return yaml_text


def write_action_blocks_yaml(
    action_blocks: list[dict[str, object]],
    output_dir: str | Path,
    *,
    file_name: str = "action_blocks.yaml",
) -> Path:
    """Write serialized action blocks YAML and return the output file path."""
    output_path = Path(output_dir).expanduser()
    output_path.mkdir(parents=True, exist_ok=True)
    file_path = output_path / file_name
    file_path.write_text(dump_action_blocks_yaml(action_blocks), encoding="utf-8")
    return file_path
